// SPDX-License-Identifier: Apache-2.0
#pragma once

#if defined(_WIN32)
#if defined(mcrt_messages_EXPORTS)
#define MCRT_MESSAGES_API __declspec(dllexport)
#else
#define MCRT_MESSAGES_API __declspec(dllimport)
#endif
#else
#define MCRT_MESSAGES_API
#endif
