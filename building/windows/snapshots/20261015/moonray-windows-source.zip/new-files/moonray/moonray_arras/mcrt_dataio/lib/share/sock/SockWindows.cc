// SPDX-License-Identifier: Apache-2.0
#include <winsock2.h>
#include <ws2tcpip.h>
#include <afunix.h>

#include "SockClient.h"
#include "SockServerInet.h"
#include "SockServerUnix.h"
#include "SockServerConnection.h"

#include <algorithm>
#include <chrono>
#include <climits>
#include <cstdio>
#include <cstring>
#include <iostream>
#include <thread>

namespace mcrt_dataio {
namespace {
bool initializeSockets()
{
    struct Runtime {
        WSADATA data{};
        int error = WSAStartup(MAKEWORD(2, 2), &data);
        ~Runtime() { if (!error) WSACleanup(); }
    };
    static Runtime runtime;
    return runtime.error == 0;
}

struct OwnedSocket {
    SOCKET value;
    ~OwnedSocket() { if (value != INVALID_SOCKET) closesocket(value); }
    SOCKET release() { SOCKET result = value; value = INVALID_SOCKET; return result; }
};

bool setBlocking(SOCKET socket, bool blocking)
{
    u_long nonblocking = blocking ? 0 : 1;
    return ioctlsocket(socket, FIONBIO, &nonblocking) == 0;
}

bool unixAddress(const std::string& path, sockaddr_un& address)
{
    // Windows supports filesystem AF_UNIX endpoints, but not Linux abstract names.
    if (path.empty() || path.front() == '@' || path.size() >= sizeof(address.sun_path)) return false;
    address = {};
    address.sun_family = AF_UNIX;
    std::memcpy(address.sun_path, path.c_str(), path.size() + 1);
    return true;
}

bool transientError(int error)
{
    return error == WSAEINTR || error == WSAEWOULDBLOCK;
}
}

void SockCoreSimple::close() { closeSock(); }
void SockCoreSimple::connectionClosed() { closeSock(); }
void SockCoreSimple::closeSock()
{
    if (mSock != INVALID_SOCKET) {
        closesocket(mSock);
        mSock = INVALID_SOCKET;
    }
}

bool SockCoreSimple::sendData(const void* data, size_t size)
{
    if (mSock == INVALID_SOCKET) return true; // Existing closed-socket contract.
    const char* cursor = static_cast<const char*>(data);
    while (size) {
        int sent = ::send(mSock, cursor, static_cast<int>(std::min(size, size_t(INT_MAX))), 0);
        if (sent == SOCKET_ERROR && transientError(WSAGetLastError())) continue;
        if (sent <= 0) { connectionClosed(); return false; }
        cursor += sent;
        size -= sent;
    }
    return true;
}

int SockCoreSimple::busyRecv(void* data, size_t size) { return recvData(data, size); }
int SockCoreSimple::recvData(void* data, size_t size)
{
    if (size > INT_MAX) return RECV_STATUS_ERROR; // The public result is an int.
    size_t received = 0;
    while (received < size) {
        int count = ::recv(mSock, static_cast<char*>(data) + received,
                           static_cast<int>(size - received), 0);
        if (count == SOCKET_ERROR) {
            const int error = WSAGetLastError();
            if (transientError(error)) continue;
            connectionClosed();
            return error == WSAECONNRESET ? RECV_STATUS_EOF : RECV_STATUS_ERROR;
        }
        if (!count) { connectionClosed(); return RECV_STATUS_EOF; }
        received += count;
    }
    return static_cast<int>(received);
}

bool SockClient::open(const std::string& host, int port, const std::string& path)
{
    if (!initializeSockets()) return false;
    mHostName = host;
    mPort = port;
    mUnixDomainSockPath = path;
    for (int i = 0; i < 9; ++i) {
        if (openSockMain(i == 8)) return true;
        if (i != 8) std::this_thread::sleep_for(std::chrono::milliseconds(500));
    }
    return false;
}

bool SockClient::openSockMain(bool errors)
{
    return mHostName == "localhost" ? openUnixSockMain(errors) : openInetSockMain(errors);
}

bool SockClient::openInetSockMain(bool errors)
{
    addrinfo hints{};
    hints.ai_family = AF_INET;
    hints.ai_socktype = SOCK_STREAM;
    addrinfo* addresses = nullptr;
    const std::string port = std::to_string(mPort);
    if (getaddrinfo(mHostName.c_str(), port.c_str(), &hints, &addresses)) return false;
    bool connected = false;
    for (auto* address = addresses; address; address = address->ai_next) {
        OwnedSocket socket{::socket(address->ai_family, SOCK_STREAM, 0)};
        if (socket.value == INVALID_SOCKET) continue;
        if (::connect(socket.value, address->ai_addr, static_cast<int>(address->ai_addrlen))) continue;
        const int enabled = 1;
        if (setsockopt(socket.value, IPPROTO_TCP, TCP_NODELAY,
                       reinterpret_cast<const char*>(&enabled), sizeof(enabled))) continue;
        mCore.close();
        mCore.setSock(socket.release());
        connected = true;
        break;
    }
    freeaddrinfo(addresses);
    if (!connected && errors) std::cerr << "Could not connect to " << mHostName << ':' << mPort << '\n';
    return connected;
}

bool SockClient::openUnixSockMain(bool errors)
{
    sockaddr_un address{};
    const std::string path = mUnixDomainSockPath + '.' + std::to_string(mPort);
    if (!unixAddress(path, address)) {
        if (errors) std::cerr << "Windows IPC requires a filesystem socket path: " << path << '\n';
        return false;
    }
    OwnedSocket socket{::socket(AF_UNIX, SOCK_STREAM, 0)};
    if (socket.value == INVALID_SOCKET || ::connect(socket.value,
            reinterpret_cast<const sockaddr*>(&address), sizeof(address))) return false;
    mCore.close();
    mCore.setSock(socket.release());
    return true;
}

bool SockServerConnection::setInetSock(SocketHandle socket, const std::string& host, int port)
{
    OwnedSocket owner{socket};
    const int enabled = 1;
    if (setsockopt(socket, IPPROTO_TCP, TCP_NODELAY,
                   reinterpret_cast<const char*>(&enabled), sizeof(enabled))) return false;
    if (!setupSendRecvBuffer(socket)) return false;
    mDomainType = DomainType::INETDOMAIN;
    mClientHost = host;
    mClientPort = port;
    mClientPath.clear();
    mCore.setSock(owner.release());
    return true;
}

bool SockServerConnection::setUnixSock(SocketHandle socket, const std::string& path)
{
    mDomainType = DomainType::UNIXDOMAIN;
    mClientPath = path;
    mClientHost.clear();
    mClientPort = 0;
    mCore.setSock(socket);
    return true;
}

bool SockServerConnection::setupSendRecvBuffer(SocketHandle socket)
{
    return scene_rdl2::grid_util::setSockBufferSize(socket, SOL_SOCKET, 4 * 1024 * 1024);
}

SockServerInet::~SockServerInet() { closeBaseSock(); }
void SockServerInet::closeBaseSock()
{
    if (mBaseSock != INVALID_SOCKET) closesocket(mBaseSock);
    mBaseSock = INVALID_SOCKET;
}

bool SockServerInet::open(int port)
{
    mPort = port;
    return initializeSockets() && (port != 0 || baseSockBindAndListen());
}

bool SockServerInet::baseSockBindAndListen()
{
    if (mBaseSock != INVALID_SOCKET) return true;
    OwnedSocket socket{::socket(AF_INET, SOCK_STREAM, 0)};
    if (socket.value == INVALID_SOCKET) return false;
    sockaddr_in address{};
    address.sin_family = AF_INET;
    address.sin_port = htons(static_cast<u_short>(mPort));
    if (bind(socket.value, reinterpret_cast<const sockaddr*>(&address), sizeof(address))) return false;
    int size = sizeof(address);
    if (getsockname(socket.value, reinterpret_cast<sockaddr*>(&address), &size)) return false;
    if (listen(socket.value, SOMAXCONN) || !setBlocking(socket.value, false)) return false;
    mPort = ntohs(address.sin_port);
    mBaseSock = socket.release();
    return true;
}

bool SockServerInet::acceptNewSocket(SocketHandle* socket, std::string& host, int* port) const
{
    sockaddr_in address{};
    int size = sizeof(address);
    *socket = accept(mBaseSock, reinterpret_cast<sockaddr*>(&address), &size);
    if (*socket == INVALID_SOCKET) return transientError(WSAGetLastError());
    if (!setBlocking(*socket, true)) { closesocket(*socket); *socket = INVALID_SOCKET; return false; }
    char text[INET_ADDRSTRLEN]{};
    inet_ntop(AF_INET, &address.sin_addr, text, sizeof(text));
    host = text;
    *port = ntohs(address.sin_port);
    return true;
}

SockServerInet::ConnectionShPtr SockServerInet::newClientConnection()
{
    if (!baseSockBindAndListen()) return {};
    SocketHandle socket;
    std::string host;
    int port;
    if (!acceptNewSocket(&socket, host, &port) || socket == INVALID_SOCKET) return {};
    auto connection = std::make_shared<SockServerConnection>();
    if (!connection->setInetSock(socket, host, port)) return {};
    return connection;
}

SockServerUnix::~SockServerUnix()
{
    const bool bound = mBaseSock != INVALID_SOCKET;
    closeBaseSock();
    if (bound) std::remove(mPath.c_str());
}

void SockServerUnix::closeBaseSock()
{
    if (mBaseSock != INVALID_SOCKET) closesocket(mBaseSock);
    mBaseSock = INVALID_SOCKET;
}

bool SockServerUnix::open(const std::string& path, int port)
{
    mPath = path + '.' + std::to_string(port);
    sockaddr_un address{};
    return initializeSockets() && unixAddress(mPath, address);
}

bool SockServerUnix::baseSockBindAndListen()
{
    if (mBaseSock != INVALID_SOCKET) return true;
    sockaddr_un address{};
    if (!unixAddress(mPath, address)) return false;
    OwnedSocket socket{::socket(AF_UNIX, SOCK_STREAM, 0)};
    if (socket.value == INVALID_SOCKET) return false;
    if (bind(socket.value, reinterpret_cast<const sockaddr*>(&address), sizeof(address))) return false;
    if (listen(socket.value, SOMAXCONN) || !setBlocking(socket.value, false)) {
        closesocket(socket.release());
        std::remove(mPath.c_str());
        return false;
    }
    mBaseSock = socket.release();
    return true;
}

bool SockServerUnix::acceptNewSocket(SocketHandle* socket, std::string& path) const
{
    *socket = accept(mBaseSock, nullptr, nullptr);
    if (*socket == INVALID_SOCKET) return transientError(WSAGetLastError());
    if (!setBlocking(*socket, true)) { closesocket(*socket); *socket = INVALID_SOCKET; return false; }
    path = mPath;
    return true;
}

SockServerUnix::ConnectionShPtr SockServerUnix::newClientConnection()
{
    if (!baseSockBindAndListen()) return {};
    SocketHandle socket;
    std::string path;
    if (!acceptNewSocket(&socket, path) || socket == INVALID_SOCKET) return {};
    auto connection = std::make_shared<SockServerConnection>();
    if (!connection->setUnixSock(socket, path)) return {};
    return connection;
}
} // namespace mcrt_dataio
