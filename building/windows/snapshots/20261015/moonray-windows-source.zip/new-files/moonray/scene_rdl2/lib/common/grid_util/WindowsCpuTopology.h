// Copyright 2026 DreamWorks Animation LLC
// SPDX-License-Identifier: Apache-2.0
#pragma once

#include <windows.h>
#include <psapi.h>

#include <algorithm>
#include <cstdint>
#include <system_error>
#include <vector>

namespace scene_rdl2::grid_util::windows_cpu {

inline void check(BOOL success, const char* operation)
{
    if (!success) throw std::system_error(GetLastError(), std::system_category(), operation);
}

inline size_t pageSize()
{
    SYSTEM_INFO info;
    GetSystemInfo(&info);
    return info.dwPageSize;
}

inline std::vector<unsigned> nodeIds()
{
    ULONG highest;
    check(GetNumaHighestNodeNumber(&highest), "GetNumaHighestNodeNumber");
    std::vector<unsigned> ids;
    for (ULONG node = 0; node <= highest; ++node) {
        ULONGLONG memory;
        if (GetNumaAvailableMemoryNodeEx(static_cast<USHORT>(node), &memory)) ids.push_back(node);
    }
    return ids;
}

inline std::vector<unsigned> cpusForNode(unsigned node)
{
    std::vector<unsigned> cpus;
    unsigned offset = 0;
    for (WORD group = 0; group < GetActiveProcessorGroupCount(); ++group) {
        const DWORD count = GetActiveProcessorCount(group);
        for (DWORD cpu = 0; cpu < count; ++cpu) {
            PROCESSOR_NUMBER processor{group, static_cast<BYTE>(cpu), 0};
            USHORT actualNode;
            check(GetNumaProcessorNodeEx(&processor, &actualNode), "GetNumaProcessorNodeEx");
            if (actualNode == node) cpus.push_back(offset + cpu);
        }
        offset += count;
    }
    return cpus;
}

inline unsigned nodeForAddress(void* address)
{
    PSAPI_WORKING_SET_EX_INFORMATION info{};
    info.VirtualAddress = address;
    check(QueryWorkingSetEx(GetCurrentProcess(), &info, sizeof(info)), "QueryWorkingSetEx");
    if (!info.VirtualAttributes.Valid) {
        throw std::runtime_error("NUMA location is unavailable for a nonresident memory page");
    }
    return static_cast<unsigned>(info.VirtualAttributes.Node);
}

inline void processorPackages(std::vector<int>& cpuIds, std::vector<int>& socketIds)
{
    DWORD bytes = 0;
    GetLogicalProcessorInformationEx(RelationProcessorPackage, nullptr, &bytes);
    std::vector<unsigned char> buffer(bytes);
    check(GetLogicalProcessorInformationEx(RelationProcessorPackage,
        reinterpret_cast<PSYSTEM_LOGICAL_PROCESSOR_INFORMATION_EX>(buffer.data()), &bytes),
        "GetLogicalProcessorInformationEx");
    int packageId = 0;
    for (DWORD pos = 0; pos < bytes; ++packageId) {
        const auto* info = reinterpret_cast<const SYSTEM_LOGICAL_PROCESSOR_INFORMATION_EX*>(buffer.data() + pos);
        for (WORD groupIndex = 0; groupIndex < info->Processor.GroupCount; ++groupIndex) {
            const auto& group = info->Processor.GroupMask[groupIndex];
            unsigned offset = 0;
            for (WORD preceding = 0; preceding < group.Group; ++preceding) {
                offset += GetActiveProcessorCount(preceding);
            }
            for (unsigned bit = 0; bit < sizeof(KAFFINITY) * 8; ++bit) {
                if (group.Mask & (KAFFINITY{1} << bit)) {
                    cpuIds.push_back(static_cast<int>(offset + bit));
                    socketIds.push_back(packageId);
                }
            }
        }
        pos += info->Size;
    }
}

} // namespace scene_rdl2::grid_util::windows_cpu
