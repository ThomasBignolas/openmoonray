// SPDX-License-Identifier: Apache-2.0
#pragma once

#include "RenderOutput.h"
#include <utility>

namespace scene_rdl2 { namespace rdl2 {

// Matches CryptomatteBuffer::outputFragments, including its padded final pair.
// Shared by the worker's lossless transport and the host's extra-AOV interface.
inline std::vector<std::pair<std::string, unsigned>>
cryptomatteLayout(const RenderOutput& ro)
{
    std::vector<std::pair<std::string, unsigned>> planes;
    const int layers = ro.getCryptomatteNumLayers();
    const auto numbered = [](const std::string& prefix, int i) {
        return prefix + (i < 10 ? "0" : "") + std::to_string(i);
    };
    for (int kind = 0; kind < 3; ++kind) {
        if (kind == 1 && !ro.getCryptomatteRecordReflected()) continue;
        if (kind == 2 && !ro.getCryptomatteRecordRefracted()) continue;
        const std::string suffix = kind == 1 ? "Reflect" : kind == 2 ? "Refract" : "";
        for (int i = 0; i < layers; ++i)
            planes.emplace_back(numbered("Cryptomatte" + suffix, i), 4);
        for (int i = 0; i < layers * 2; ++i) {
            const auto add = [&](bool enabled, const char* name, unsigned channels) {
                if (enabled) {
                    std::string prefix(name);
                    prefix.insert(6, suffix); // CryptoReflectP, CryptoRefractUV, etc.
                    planes.emplace_back(numbered(prefix, i), channels);
                }
            };
            add(ro.getCryptomatteOutputPositions(), "CryptoP", 4);
            add(ro.getCryptomatteOutputP0(), "CryptoP0", 4);
            add(ro.getCryptomatteOutputNormals(), "CryptoN", 4);
            add(ro.getCryptomatteOutputBeauty(), "CryptoB", 4);
            add(ro.getCryptomatteOutputRefP(), "CryptoRefP", 4);
            add(ro.getCryptomatteOutputRefN(), "CryptoRefN", 4);
            add(ro.getCryptomatteOutputUV(), "CryptoUV", 2);
            add(ro.getCryptomatteSupportResumeRender(), "CryptoS", 2);
        }
    }
    return planes;
}

} }
