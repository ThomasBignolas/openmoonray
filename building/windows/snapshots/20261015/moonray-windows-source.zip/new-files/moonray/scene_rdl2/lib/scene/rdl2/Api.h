// SPDX-License-Identifier: Apache-2.0
#pragma once

// Windows clients must import shared data through the DLL's import table.
// Automatic function exports alone cannot provide this for inline accessors.
#if defined(_WIN32)
# if defined(scene_rdl2_tmp_EXPORTS)
#  define SCENE_RDL2_API __declspec(dllexport)
# else
#  define SCENE_RDL2_API __declspec(dllimport)
# endif
#else
# define SCENE_RDL2_API
#endif
