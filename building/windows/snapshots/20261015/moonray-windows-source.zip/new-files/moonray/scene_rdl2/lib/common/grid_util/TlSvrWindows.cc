// Copyright 2026 DreamWorks Animation LLC
// SPDX-License-Identifier: Apache-2.0
#include <winsock2.h>
#include "TlSvr.h"
#include "SockUtil.h"

#include <algorithm>
#include <limits>
#include <system_error>

namespace scene_rdl2::grid_util {
namespace {
void socketError(const TlSvr::ERRMSG_CALLBACK& callback, const char* operation)
{
    if (callback) callback(std::string(operation) + ": " +
        std::system_category().message(WSAGetLastError()));
}

bool nonblocking(SOCKET socket)
{
    u_long enabled = 1;
    return ioctlsocket(socket, FIONBIO, &enabled) == 0;
}
}

TlSvr::TlSvr()
    : mPort(-1), mBaseSock(INVALID_SOCKET), mSock(INVALID_SOCKET),
      mConnectionReady(false), mRecvSize(0), mEndLine(false)
{
    WSADATA data;
    const int error = WSAStartup(MAKEWORD(2, 2), &data);
    if (error) throw std::system_error(error, std::system_category(), "WSAStartup");
}

TlSvr::~TlSvr()
{
    close();
    WSACleanup();
}

int TlSvr::open(int port, INFOMSG_CALLBACK info, ERRMSG_CALLBACK error)
{
    close();
    if (port < 0 || port > 65535) return 0;
    mPort = port;
    if (port == 0 && !socketBindAndListen(info, error)) return 0;
    return mPort;
}

bool TlSvr::socketBindAndListen(INFOMSG_CALLBACK info, ERRMSG_CALLBACK error)
{
    mBaseSock = WSASocketW(AF_INET, SOCK_STREAM, IPPROTO_TCP, nullptr, 0, WSA_FLAG_NO_HANDLE_INHERIT);
    if (mBaseSock == INVALID_SOCKET) { socketError(error, "socket"); return false; }
    auto fail = [&](const char* operation) {
        socketError(error, operation);
        closesocket(mBaseSock);
        mBaseSock = INVALID_SOCKET;
        return false;
    };
    const BOOL exclusive = TRUE;
    if (setsockopt(mBaseSock, SOL_SOCKET, SO_EXCLUSIVEADDRUSE,
                   reinterpret_cast<const char*>(&exclusive), sizeof(exclusive)) != 0) return fail("setsockopt");
    if (!nonblocking(mBaseSock)) return fail("ioctlsocket");
    sockaddr_in address{};
    address.sin_family = AF_INET;
    address.sin_addr.s_addr = htonl(INADDR_ANY);
    address.sin_port = htons(static_cast<u_short>(mPort));
    if (bind(mBaseSock, reinterpret_cast<sockaddr*>(&address), sizeof(address)) != 0) return fail("bind");
    int size = sizeof(address);
    if (getsockname(mBaseSock, reinterpret_cast<sockaddr*>(&address), &size) != 0) return fail("getsockname");
    mPort = ntohs(address.sin_port);
    if (listen(mBaseSock, 5) != 0) return fail("listen");
    if (info) info("Opened server port " + std::to_string(mPort));
    return true;
}

bool TlSvr::setupServerPort(INFOMSG_CALLBACK info, ERRMSG_CALLBACK error)
{
    if (mPort < 0) return true;
    if (mSock != INVALID_SOCKET) return true;
    if (mBaseSock == INVALID_SOCKET && !socketBindAndListen(info, error)) return false;
    return acceptSocket(info, error);
}

bool TlSvr::acceptSocket(INFOMSG_CALLBACK info, ERRMSG_CALLBACK error)
{
    mSock = accept(mBaseSock, nullptr, nullptr);
    if (mSock == INVALID_SOCKET) {
        if (WSAGetLastError() == WSAEWOULDBLOCK) return true;
        socketError(error, "accept");
        return false;
    }
    const BOOL enabled = TRUE;
    if (!SetHandleInformation(reinterpret_cast<HANDLE>(mSock), HANDLE_FLAG_INHERIT, 0) ||
        !nonblocking(mSock) ||
        setsockopt(mSock, IPPROTO_TCP, TCP_NODELAY, reinterpret_cast<const char*>(&enabled), sizeof(enabled)) != 0 ||
        setsockopt(mSock, SOL_SOCKET, SO_KEEPALIVE, reinterpret_cast<const char*>(&enabled), sizeof(enabled)) != 0 ||
        !setSockBufferSize(mSock, SOL_SOCKET, 64 * 1024)) {
        socketError(error, "configure client socket");
        connectionClosed(nullptr);
        return false;
    }
    closesocket(mBaseSock);
    mBaseSock = INVALID_SOCKET;
    mConnectionReady = true;
    mRecvSize = 0;
    mEndLine = true;
    if (info) info("Connection established on port " + std::to_string(mPort));
    return true;
}

int TlSvr::socketCheck(ERRMSG_CALLBACK error)
{
    fd_set descriptors;
    FD_ZERO(&descriptors);
    FD_SET(mSock, &descriptors);
    timeval timeout{};
    const int result = select(0, &descriptors, nullptr, nullptr, &timeout);
    if (result == SOCKET_ERROR) socketError(error, "select");
    return result;
}

int TlSvr::recv(std::string& text, INFOMSG_CALLBACK info, ERRMSG_CALLBACK error)
{
    if (mPort < 0) return 0;
    if (!setupServerPort(info, error)) return -2;
    if (mSock == INVALID_SOCKET) return 0;
    if (mEndLine) { mPartialLine.clear(); mRecvSize = 0; mEndLine = false; }
    for (;;) {
        char value;
        const int count = ::recv(mSock, &value, 1, 0);
        if (count == 1) {
            if (value == '\r') continue;
            mPartialLine += value == '\0' ? '\n' : value;
            ++mRecvSize;
            if (value == '\n' || value == '\0') {
                text = mPartialLine;
                mEndLine = true;
                return mRecvSize;
            }
        } else if (count == 0) {
            connectionClosed(info);
            if (mRecvSize) {
                text = mPartialLine + '\n';
                mEndLine = true;
                return ++mRecvSize;
            }
            return -1;
        } else {
            const int code = WSAGetLastError();
            if (code == WSAEWOULDBLOCK) { text = mPartialLine; return 0; }
            if (code == WSAEINTR) continue;
            socketError(error, "recv");
            connectionClosed(info);
            return code == WSAECONNRESET ? -1 : -2;
        }
    }
}

bool TlSvr::send(const std::string& text, INFOMSG_CALLBACK info, ERRMSG_CALLBACK error)
{
    if (!mConnectionReady) return true;
    size_t offset = 0;
    while (offset < text.size()) {
        const int count = ::send(mSock, text.data() + offset,
            static_cast<int>(std::min(text.size() - offset, static_cast<size_t>(std::numeric_limits<int>::max()))), 0);
        if (count > 0) { offset += count; continue; }
        const int code = WSAGetLastError();
        if (count == SOCKET_ERROR && code == WSAEINTR) continue;
        if (count == SOCKET_ERROR && code == WSAEWOULDBLOCK) {
            fd_set writable;
            FD_ZERO(&writable);
            FD_SET(mSock, &writable);
            if (select(0, nullptr, &writable, nullptr, nullptr) > 0) continue;
        }
        socketError(error, "send");
        connectionClosed(info);
        return false;
    }
    return true;
}

void TlSvr::connectionClosed(INFOMSG_CALLBACK info)
{
    if (mSock != INVALID_SOCKET) closesocket(mSock);
    mSock = INVALID_SOCKET;
    mConnectionReady = false;
    if (info) info("Connection closed on port " + std::to_string(mPort));
}

void TlSvr::close()
{
    connectionClosed(nullptr);
    if (mBaseSock != INVALID_SOCKET) closesocket(mBaseSock);
    mBaseSock = INVALID_SOCKET;
    mPort = -1;
}

bool TlSvr::isConnectionEstablised() const { return mConnectionReady; }
} // namespace scene_rdl2::grid_util
