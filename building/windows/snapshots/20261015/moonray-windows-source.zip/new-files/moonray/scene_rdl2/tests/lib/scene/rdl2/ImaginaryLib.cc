// SPDX-License-Identifier: Apache-2.0
#include "ImaginaryLib.h"
#include <stdexcept>

void ImaginaryThing::doTheThing()
{
    throw std::runtime_error("The proxy test must not load its implementation dependency");
}
