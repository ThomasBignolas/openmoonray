// Copyright 2026 DreamWorks Animation LLC
// SPDX-License-Identifier: Apache-2.0
#pragma once

#include <cstddef>
#include <ctime>
#include <string>
#include <vector>

namespace scene_rdl2::grid_util::windows_shm {

// Private adapter for the subset of System V shared memory used by grid_util.
// Windows storage is per user, persists after process exit, and uses the user's
// SID ACL rather than Unix permission bits. mode is retained as a data category.
constexpr int IPC_PRIVATE = 0;
constexpr int IPC_CREAT = 01000;
constexpr int IPC_EXCL = 02000;
constexpr int IPC_STAT = 1;
constexpr int IPC_RMID = 2;
constexpr int SHM_RDONLY = 010000;
constexpr int SHM_R = 0400;
constexpr int SHM_W = 0200;

struct shmid_ds {
    struct { int mode = 0; } shm_perm;
    size_t shm_segsz = 0;
    unsigned shm_nattch = 0;
    std::string owner;
    int key = 0;
};

// Errors follow the existing callers' errno contract. IDs are positive and are
// independent of keys. A maximum of 4096 simultaneous attachments per segment
// is tracked with kernel file locks, including multiple views in one process.
int shmget(int key, size_t size, int flags);
void* shmat(int id, const void* requestedAddress, int flags);
int shmdt(const void* address);
int shmctl(int id, int command, shmid_ds* info);
bool removeUnused(int id);
std::vector<int> list();

// Binary semaphore adapter for AffinityMapTable. SEM_UNDO is implemented with
// a kernel-owned file lock, so termination releases a held semaphore. This is
// deliberately not a general System V semaphore-set implementation.
constexpr int SETVAL = 3;
constexpr int SEM_UNDO = 010000;
constexpr int IPC_NOWAIT = 04000;
struct sembuf { unsigned short sem_num; short sem_op; short sem_flg; };
struct semid_ds {
    struct { int mode = 0; } sem_perm;
    int key = 0;
    std::string owner;
};
int semget(int key, int count, int flags);
int semctl(int id, int index, int command, int value = 0);
int semctl(int id, int index, int command, semid_ds* info);
int semop(int id, const sembuf* operation, size_t count);
int semtimedop(int id, const sembuf* operation, size_t count, const timespec* timeout);
std::vector<int> listSemaphores();

} // namespace scene_rdl2::grid_util::windows_shm
