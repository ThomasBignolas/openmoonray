// SPDX-License-Identifier: Apache-2.0
#pragma once

#include <filesystem>
#include <stdexcept>
#include <string>
#include <system_error>

#ifdef _WIN32
#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#ifndef NOMINMAX
#define NOMINMAX
#endif
#include <windows.h>
#else
#include <dlfcn.h>
#endif

namespace scene_rdl2::util {

// Owns one loader reference. RDL2 factories keep this alive while objects
// and function pointers from the library are in use.
class DynamicLibrary
{
public:
    explicit DynamicLibrary(const std::string& path)
    {
#ifdef _WIN32
        const auto absolute = std::filesystem::absolute(std::filesystem::u8path(path));
        // Search the plugin's directory for its dependencies before the usual
        // process search path, without changing the process DLL directories.
        mHandle = LoadLibraryExW(absolute.c_str(), nullptr, LOAD_WITH_ALTERED_SEARCH_PATH);
        if (!mHandle) {
            throw std::system_error(GetLastError(), std::system_category(), "LoadLibraryExW");
        }
#else
        mHandle = dlopen(path.c_str(), RTLD_LAZY);
        if (!mHandle) {
            const char* error = dlerror();
            throw std::runtime_error(error ? error : "dlopen failed");
        }
#endif
    }

    ~DynamicLibrary()
    {
#ifdef _WIN32
        FreeLibrary(mHandle);
#else
        dlclose(mHandle);
#endif
    }

    DynamicLibrary(const DynamicLibrary&) = delete;
    DynamicLibrary& operator=(const DynamicLibrary&) = delete;

    void* symbol(const char* name) const
    {
#ifdef _WIN32
        const auto result = GetProcAddress(mHandle, name);
        if (!result) {
            throw std::system_error(GetLastError(), std::system_category(), name);
        }
        return reinterpret_cast<void*>(result);
#else
        dlerror();
        void* result = dlsym(mHandle, name);
        const char* error = dlerror();
        if (error || !result) {
            throw std::runtime_error(error ? error : "Null function symbol");
        }
        return result;
#endif
    }

private:
#ifdef _WIN32
    HMODULE mHandle;
#else
    void* mHandle;
#endif
};

} // namespace scene_rdl2::util
