// Copyright 2026 DreamWorks Animation LLC
// SPDX-License-Identifier: Apache-2.0
#include "WindowsSharedMemory.h"

#include <windows.h>
#include <sddl.h>
#include <shlobj.h>
#include <bcrypt.h>

#include <array>
#include <cerrno>
#include <chrono>
#include <cstdint>
#include <cstring>
#include <filesystem>
#include <limits>
#include <map>
#include <memory>
#include <stdexcept>
#include <system_error>
#include <thread>
#include <utility>

namespace scene_rdl2::grid_util::windows_shm {
namespace {
// The prefix is separate from the payload, which remains 64 KiB aligned.
constexpr DWORD payloadOffset = 65536;
constexpr DWORD leaseOffset = 4096;
constexpr unsigned maxAttachments = 4096;
constexpr DWORD semaphoreOffset = leaseOffset + maxAttachments;
constexpr uint64_t magic = 0x314d4853524d4f; // OMRSHM1
struct Header {
    uint64_t signature = magic;
    uint64_t size = 0;
    int32_t id = 0;
    int32_t key = 0;
    uint32_t mode = 0;
    uint32_t removed = 0;
    uint32_t kind = 0; // 0: shared memory, 1: binary semaphore
    uint32_t initialized = 0;
    char owner[512] = {};
};
static_assert(sizeof(Header) < leaseOffset);

class Handle {
public:
    explicit Handle(HANDLE value = INVALID_HANDLE_VALUE) : mValue(value) {}
    ~Handle() { if (valid()) CloseHandle(mValue); }
    Handle(const Handle&) = delete;
    Handle& operator=(const Handle&) = delete;
    HANDLE get() const { return mValue; }
    bool valid() const { return mValue && mValue != INVALID_HANDLE_VALUE; }
private:
    HANDLE mValue;
};

[[noreturn]] void fail(DWORD error = GetLastError())
{
    throw std::system_error(static_cast<int>(error), std::system_category());
}

int translateError()
{
    try { throw; }
    catch (const std::system_error& e) {
        switch (e.code().value()) {
        case ERROR_FILE_NOT_FOUND: case ERROR_PATH_NOT_FOUND: errno = ENOENT; break;
        case ERROR_FILE_EXISTS: case ERROR_ALREADY_EXISTS: errno = EEXIST; break;
        case ERROR_ACCESS_DENIED: errno = EACCES; break;
        case ERROR_LOCK_VIOLATION: case ERROR_BUSY: errno = EBUSY; break;
        case ERROR_NOT_ENOUGH_MEMORY: case ERROR_OUTOFMEMORY: errno = ENOMEM; break;
        case ERROR_DISK_FULL: case ERROR_TOO_MANY_OPEN_FILES: errno = ENOSPC; break;
        case ERROR_INVALID_PARAMETER: case ERROR_BAD_FORMAT: errno = EINVAL; break;
        default: errno = EIO; break;
        }
    }
    catch (const std::bad_alloc&) { errno = ENOMEM; }
    catch (...) { errno = EIO; }
    return -1;
}

std::wstring userSid()
{
    HANDLE rawToken = nullptr;
    if (!OpenProcessToken(GetCurrentProcess(), TOKEN_QUERY, &rawToken)) fail();
    Handle token(rawToken);
    DWORD size = 0;
    GetTokenInformation(token.get(), TokenUser, nullptr, 0, &size);
    std::vector<unsigned char> data(size);
    if (!GetTokenInformation(token.get(), TokenUser, data.data(), size, &size)) fail();
    LPWSTR rawSid = nullptr;
    if (!ConvertSidToStringSidW(reinterpret_cast<TOKEN_USER*>(data.data())->User.Sid, &rawSid)) fail();
    std::wstring sid(rawSid);
    LocalFree(rawSid);
    return sid;
}

const std::filesystem::path& directory()
{
    static const auto dir = [] {
        PWSTR rawPath = nullptr;
        if (FAILED(SHGetKnownFolderPath(FOLDERID_LocalAppData, 0, nullptr, &rawPath)))
            fail(ERROR_PATH_NOT_FOUND);
        std::filesystem::path result(rawPath);
        CoTaskMemFree(rawPath);
        result /= L"OpenMoonRay";
        std::filesystem::create_directories(result);
        result /= L"shared-memory-v1";
        const std::wstring acl = L"D:P(A;OICI;FA;;;SY)(A;OICI;FA;;;" + userSid() + L")";
        PSECURITY_DESCRIPTOR descriptor = nullptr;
        if (!ConvertStringSecurityDescriptorToSecurityDescriptorW(acl.c_str(), SDDL_REVISION_1,
                                                                  &descriptor, nullptr)) fail();
        SECURITY_ATTRIBUTES attributes{sizeof(SECURITY_ATTRIBUTES), descriptor, FALSE};
        const bool created = CreateDirectoryW(result.c_str(), &attributes) != FALSE;
        const DWORD error = GetLastError();
        LocalFree(descriptor);
        if (!created && error != ERROR_ALREADY_EXISTS) fail(error);
        const DWORD fileAttributes = GetFileAttributesW(result.c_str());
        if (fileAttributes == INVALID_FILE_ATTRIBUTES || !(fileAttributes & FILE_ATTRIBUTE_DIRECTORY) ||
            (fileAttributes & FILE_ATTRIBUTE_REPARSE_POINT)) fail(ERROR_ACCESS_DENIED);
        return result;
    }();
    return dir;
}

std::filesystem::path path(int id) { return directory() / (L"segment-" + std::to_wstring(id) + L".shm"); }

HANDLE openFile(const std::filesystem::path& name, DWORD disposition = OPEN_EXISTING)
{
    HANDLE file = CreateFileW(name.c_str(), GENERIC_READ | GENERIC_WRITE,
                             FILE_SHARE_READ | FILE_SHARE_WRITE | FILE_SHARE_DELETE,
                             nullptr, disposition, FILE_ATTRIBUTE_NORMAL | FILE_FLAG_OPEN_REPARSE_POINT, nullptr);
    if (file == INVALID_HANDLE_VALUE) fail();
    BY_HANDLE_FILE_INFORMATION info{};
    if (!GetFileInformationByHandle(file, &info) || (info.dwFileAttributes & FILE_ATTRIBUTE_REPARSE_POINT)) {
        CloseHandle(file);
        fail(ERROR_ACCESS_DENIED);
    }
    return file;
}

bool lockByte(HANDLE file, DWORD offset, bool wait = false)
{
    OVERLAPPED overlap{};
    overlap.Offset = offset;
    if (LockFileEx(file, LOCKFILE_EXCLUSIVE_LOCK | (wait ? 0 : LOCKFILE_FAIL_IMMEDIATELY),
                   0, 1, 0, &overlap)) return true;
    if (!wait && GetLastError() == ERROR_LOCK_VIOLATION) return false;
    fail();
}

void unlockByte(HANDLE file, DWORD offset)
{
    OVERLAPPED overlap{};
    overlap.Offset = offset;
    if (!UnlockFileEx(file, 0, 1, 0, &overlap)) fail();
}

// All metadata changes and attachment registry access use this same kernel lock.
// It works across login sessions and is released even after forced termination.
class RegistryLock {
public:
    RegistryLock() : mFile(openFile(directory() / L"registry.lock", OPEN_ALWAYS))
    { lockByte(mFile.get(), 0, true); }
private:
    Handle mFile;
};

Header readHeader(HANDLE file, int id)
{
    Header header{};
    DWORD bytes = 0;
    LARGE_INTEGER zero{}, length{};
    if (!SetFilePointerEx(file, zero, nullptr, FILE_BEGIN) ||
        !ReadFile(file, &header, sizeof(header), &bytes, nullptr) ||
        !GetFileSizeEx(file, &length)) fail();
    if (bytes != sizeof(header) || header.signature != magic || header.id != id || !header.size ||
        header.size > static_cast<uint64_t>(INT64_MAX) - payloadOffset ||
        length.QuadPart != static_cast<int64_t>(header.size + payloadOffset) ||
        !memchr(header.owner, '\0', sizeof(header.owner))) fail(ERROR_BAD_FORMAT);
    return header;
}

void writeHeader(HANDLE file, const Header& header)
{
    LARGE_INTEGER zero{};
    DWORD bytes = 0;
    if (!SetFilePointerEx(file, zero, nullptr, FILE_BEGIN) ||
        !WriteFile(file, &header, sizeof(header), &bytes, nullptr) || bytes != sizeof(header) ||
        !FlushFileBuffers(file)) fail();
}

unsigned attachments(HANDLE file)
{
    unsigned count = 0;
    for (unsigned i = 0; i < maxAttachments; ++i) {
        if (lockByte(file, leaseOffset + i)) unlockByte(file, leaseOffset + i);
        else ++count;
    }
    return count;
}

std::vector<int> ids()
{
    std::vector<int> result;
    for (const auto& entry : std::filesystem::directory_iterator(directory())) {
        const auto name = entry.path().filename().wstring();
        if (name.starts_with(L"segment-") && name.ends_with(L".shm")) {
            try {
                const auto digits = name.substr(8, name.size() - 12);
                size_t used = 0;
                int id = std::stoi(digits, &used);
                if (id > 0 && used == digits.size()) result.push_back(id);
            } catch (const std::exception&) { /* unrelated file */ }
        }
    }
    return result;
}

struct View {
    Handle file;
    void* base = nullptr;
    int id;
    explicit View(int segment) : file(openFile(path(segment))), id(segment) {}
    ~View() { if (base) UnmapViewOfFile(base); }
};
// Leaked singleton avoids cross-DLL static destruction order problems. Individual
// views are detached normally; Windows releases any surviving views at exit.
auto& views()
{
    static auto* value = new std::map<const void*, std::unique_ptr<View>>;
    return *value;
}

auto& heldSemaphores()
{
    static auto* value = new std::map<int, std::unique_ptr<Handle>>;
    return *value;
}

void deleteFile(int id)
{
    if (!DeleteFileW(path(id).c_str())) fail();
}
} // namespace

static int createSegment(int key, size_t size, int flags, unsigned kind)
{
    try {
        RegistryLock lock;
        if (key != IPC_PRIVATE) {
            for (int id : ids()) {
                Header header;
                try {
                    Handle file(openFile(path(id)));
                    header = readHeader(file.get(), id);
                } catch (const std::system_error& e) {
                    // A creator can die before committing its header. Such an
                    // incomplete file must not prevent unrelated allocations.
                    if (e.code().value() == ERROR_BAD_FORMAT || e.code().value() == ERROR_FILE_NOT_FOUND) continue;
                    throw;
                }
                if (header.removed || header.key != key || header.kind != kind) continue;
                if ((flags & IPC_CREAT) && (flags & IPC_EXCL)) fail(ERROR_FILE_EXISTS);
                if (size > header.size) fail(ERROR_INVALID_PARAMETER);
                return id;
            }
            if (!(flags & IPC_CREAT)) fail(ERROR_FILE_NOT_FOUND);
        }
        if (!size || size > static_cast<uint64_t>(INT64_MAX) - payloadOffset) fail(ERROR_INVALID_PARAMETER);
        Header header;
        header.size = size;
        header.key = key;
        header.mode = flags & 0777;
        header.kind = kind;
        // SID is stable, unambiguous, and does not fabricate a Unix UID/GID.
        const auto sid = userSid();
        for (size_t i = 0; i < sid.size() && i + 1 < sizeof(header.owner); ++i)
            header.owner[i] = static_cast<char>(sid[i]);
        for (;;) {
            if (BCryptGenRandom(nullptr, reinterpret_cast<PUCHAR>(&header.id), sizeof(header.id),
                                BCRYPT_USE_SYSTEM_PREFERRED_RNG) < 0) fail(ERROR_GEN_FAILURE);
            header.id &= INT32_MAX;
            if (!header.id) continue;
            if (GetFileAttributesW(path(header.id).c_str()) == INVALID_FILE_ATTRIBUTES) break;
        }
        bool created = false;
        try {
            Handle file(openFile(path(header.id), CREATE_NEW));
            created = true;
            LARGE_INTEGER length{};
            length.QuadPart = static_cast<int64_t>(size + payloadOffset);
            if (!SetFilePointerEx(file.get(), length, nullptr, FILE_BEGIN) || !SetEndOfFile(file.get())) fail();
            writeHeader(file.get(), header);
        } catch (...) {
            if (created) DeleteFileW(path(header.id).c_str());
            throw;
        }
        return header.id;
    } catch (...) { return translateError(); }
}

int shmget(int key, size_t size, int flags) { return createSegment(key, size, flags, 0); }

void* shmat(int id, const void* requestedAddress, int flags)
{
    try {
        if (id <= 0 || requestedAddress || (flags & ~SHM_RDONLY)) fail(ERROR_INVALID_PARAMETER);
        RegistryLock lock;
        auto view = std::make_unique<View>(id);
        const auto header = readHeader(view->file.get(), id);
        if (header.removed) fail(ERROR_FILE_NOT_FOUND);
        if (header.kind != 0) fail(ERROR_INVALID_PARAMETER);
        unsigned slot = 0;
        for (; slot < maxAttachments; ++slot) if (lockByte(view->file.get(), leaseOffset + slot)) break;
        if (slot == maxAttachments) fail(ERROR_TOO_MANY_OPEN_FILES);
        // Mapping handle can close immediately after the view is established.
        Handle mapping(CreateFileMappingW(view->file.get(), nullptr,
                                         flags & SHM_RDONLY ? PAGE_READONLY : PAGE_READWRITE, 0, 0, nullptr));
        if (!mapping.valid()) fail();
        view->base = MapViewOfFile(mapping.get(), flags & SHM_RDONLY ? FILE_MAP_READ : FILE_MAP_WRITE,
                                  0, payloadOffset, static_cast<SIZE_T>(header.size));
        if (!view->base) fail();
        void* data = view->base;
        views().emplace(data, std::move(view));
        return data;
    } catch (...) { translateError(); return reinterpret_cast<void*>(-1); }
}

int shmdt(const void* address)
{
    try {
        RegistryLock lock;
        auto it = views().find(address);
        if (it == views().end()) fail(ERROR_INVALID_PARAMETER);
        const int id = it->second->id;
        views().erase(it); // unmaps, closes file and releases its attachment lease
        bool remove = false;
        {
            Handle file(openFile(path(id)));
            remove = readHeader(file.get(), id).removed && attachments(file.get()) == 0;
        }
        if (remove) deleteFile(id);
        return 0;
    } catch (...) { return translateError(); }
}

int shmctl(int id, int command, shmid_ds* info)
{
    try {
        if (id <= 0 || (command != IPC_STAT && command != IPC_RMID) || (command == IPC_STAT && !info))
            fail(ERROR_INVALID_PARAMETER);
        RegistryLock lock;
        unsigned count = 0;
        {
            Handle file(openFile(path(id)));
            auto header = readHeader(file.get(), id);
            if (header.removed) fail(ERROR_FILE_NOT_FOUND);
            if (header.kind != 0) fail(ERROR_INVALID_PARAMETER);
            count = attachments(file.get());
            if (command == IPC_STAT) {
                info->shm_perm.mode = header.mode;
                info->shm_segsz = static_cast<size_t>(header.size);
                info->shm_nattch = count;
                info->owner = header.owner;
                info->key = header.key;
            } else {
                header.removed = 1;
                writeHeader(file.get(), header);
            }
        }
        if (command == IPC_RMID && count == 0) deleteFile(id);
        return 0;
    } catch (...) { return translateError(); }
}

bool removeUnused(int id)
{
    try {
        RegistryLock lock;
        {
            Handle file(openFile(path(id)));
            if (readHeader(file.get(), id).kind != 0) fail(ERROR_INVALID_PARAMETER);
            if (attachments(file.get())) fail(ERROR_BUSY);
        }
        deleteFile(id);
        return true;
    } catch (...) { translateError(); return false; }
}

std::vector<int> list()
{
    RegistryLock lock;
    std::vector<int> result;
    for (int id : ids()) {
        bool removed = false, unused = false;
        try {
            Handle file(openFile(path(id)));
            const auto header = readHeader(file.get(), id);
            if (header.kind != 0) continue;
            removed = header.removed != 0;
            unused = removed && !attachments(file.get());
        } catch (const std::system_error&) { continue; } // foreign or incomplete file
        if (unused) deleteFile(id); // reap deletion pending when last process crashed
        else if (!removed) result.push_back(id);
    }
    return result;
}

int semget(int key, int count, int flags)
{
    if (count < 0 || count > 1 || ((flags & IPC_CREAT) && count != 1)) { errno = EINVAL; return -1; }
    return createSegment(key, 1, flags, 1);
}

int semctl(int id, int index, int command, int value)
{
    try {
        if (index != 0 || (command != SETVAL && command != IPC_RMID) ||
            (command == SETVAL && value != 1)) fail(ERROR_INVALID_PARAMETER);
        RegistryLock lock;
        {
            Handle file(openFile(path(id)));
            auto header = readHeader(file.get(), id);
            if (header.kind != 1) fail(ERROR_INVALID_PARAMETER);
            if (header.removed) fail(ERROR_FILE_NOT_FOUND);
            if (command == SETVAL) {
                if (!lockByte(file.get(), semaphoreOffset)) fail(ERROR_BUSY);
                header.initialized = 1;
            } else {
                header.removed = 1;
                heldSemaphores().erase(id);
            }
            writeHeader(file.get(), header);
        }
        // No mappings exist for semaphore files. DeleteFile may mark the file
        // for deletion while another process still holds its old lock handle.
        if (command == IPC_RMID) deleteFile(id);
        return 0;
    } catch (...) { return translateError(); }
}

int semctl(int id, int index, int command, semid_ds* info)
{
    try {
        if (index != 0 || command != IPC_STAT || !info) fail(ERROR_INVALID_PARAMETER);
        RegistryLock lock;
        Handle file(openFile(path(id)));
        auto header = readHeader(file.get(), id);
        if (header.kind != 1) fail(ERROR_INVALID_PARAMETER);
        if (header.removed) fail(ERROR_FILE_NOT_FOUND);
        info->key = header.key;
        info->owner = header.owner;
        info->sem_perm.mode = header.mode;
        return 0;
    } catch (...) { return translateError(); }
}

static int trySemaphore(int id, short operation)
{
    try {
        RegistryLock lock;
        auto file = std::make_unique<Handle>(openFile(path(id)));
        const auto header = readHeader(file->get(), id);
        if (header.kind != 1) fail(ERROR_INVALID_PARAMETER);
        if (header.removed) fail(ERROR_FILE_NOT_FOUND);
        if (operation == 1) {
            if (!heldSemaphores().erase(id)) fail(ERROR_INVALID_PARAMETER);
        } else {
            if (!header.initialized || !lockByte(file->get(), semaphoreOffset)) {
                errno = EAGAIN;
                return -1;
            }
            heldSemaphores().emplace(id, std::move(file));
        }
        return 0;
    } catch (...) { return translateError(); }
}

int semtimedop(int id, const sembuf* operation, size_t count, const timespec* timeout)
{
    if (!operation || count != 1 || operation->sem_num != 0 ||
        (operation->sem_op != 1 && operation->sem_op != -1) ||
        !(operation->sem_flg & SEM_UNDO) || (operation->sem_flg & ~(SEM_UNDO | IPC_NOWAIT)) ||
        (timeout && (timeout->tv_sec < 0 || timeout->tv_nsec < 0 || timeout->tv_nsec >= 1000000000))) {
        errno = EINVAL;
        return -1;
    }
    using Clock = std::chrono::steady_clock;
    const auto start = Clock::now();
    const double timeoutSeconds = timeout ? static_cast<double>(timeout->tv_sec) + timeout->tv_nsec * 1e-9 : 0;
    for (;;) {
        const int result = trySemaphore(id, operation->sem_op);
        if (result == 0 || errno != EAGAIN) return result;
        if ((operation->sem_flg & IPC_NOWAIT) ||
            (timeout && std::chrono::duration<double>(Clock::now() - start).count() >= timeoutSeconds)) return -1;
        std::this_thread::sleep_for(std::chrono::milliseconds(1));
    }
}

int semop(int id, const sembuf* operation, size_t count) { return semtimedop(id, operation, count, nullptr); }

std::vector<int> listSemaphores()
{
    RegistryLock lock;
    std::vector<int> result;
    for (int id : ids()) {
        try {
            Handle file(openFile(path(id)));
            const auto header = readHeader(file.get(), id);
            if (header.kind == 1 && !header.removed) result.push_back(id);
        } catch (const std::system_error&) { continue; }
    }
    return result;
}

} // namespace scene_rdl2::grid_util::windows_shm
