# Copyright 2026 DreamWorks Animation LLC
# SPDX-License-Identifier: Apache-2.0
"""Concatenate sampling chunks byte-for-byte without shell redirection."""
from pathlib import Path
import shutil
import sys

with Path(sys.argv[1]).open("wb") as output:
    for name in sys.argv[2:]:
        with Path(name).open("rb") as source:
            shutil.copyfileobj(source, output)
