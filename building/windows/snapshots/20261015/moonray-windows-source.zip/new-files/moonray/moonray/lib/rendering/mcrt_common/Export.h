// SPDX-License-Identifier: Apache-2.0
#pragma once
#if defined(_WIN32) && defined(rendering_mcrt_common_EXPORTS)
#define MOONRAY_MCRT_COMMON_API __declspec(dllexport)
#elif defined(_WIN32)
#define MOONRAY_MCRT_COMMON_API __declspec(dllimport)
#else
#define MOONRAY_MCRT_COMMON_API
#endif
