// SPDX-License-Identifier: Apache-2.0
#pragma once
#if defined(_WIN32) && defined(rendering_pbr_EXPORTS)
#define MOONRAY_PBR_API __declspec(dllexport)
#elif defined(_WIN32)
#define MOONRAY_PBR_API __declspec(dllimport)
#else
#define MOONRAY_PBR_API
#endif
