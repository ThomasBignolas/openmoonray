// SPDX-License-Identifier: Apache-2.0

#pragma once

#if defined(_WIN32) && defined(rendering_shading_EXPORTS)
#define MOONRAY_SHADING_API __declspec(dllexport)
#elif defined(_WIN32)
#define MOONRAY_SHADING_API __declspec(dllimport)
#else
#define MOONRAY_SHADING_API
#endif
