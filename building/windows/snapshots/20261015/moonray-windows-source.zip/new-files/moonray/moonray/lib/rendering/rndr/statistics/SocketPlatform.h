// SPDX-License-Identifier: Apache-2.0
#pragma once

#include <cerrno>
#include <cstddef>
#include <stdexcept>
#include <system_error>

#ifdef _WIN32
#include <winsock2.h>
#include <ws2tcpip.h>
#else
#include <netdb.h>
#include <netinet/in.h>
#include <sys/select.h>
#include <sys/socket.h>
#include <unistd.h>
#endif

namespace moonray { namespace stats { namespace socket_platform {
#ifdef _WIN32
using Handle = SOCKET;
using Length = int;
constexpr Handle invalid = INVALID_SOCKET;
inline void initialize()
{
    struct Runtime {
        Runtime() {
            WSADATA data;
            const int error = WSAStartup(MAKEWORD(2, 2), &data);
            if (error) throw std::system_error(error, std::system_category(), "WSAStartup");
        }
        ~Runtime() { WSACleanup(); }
    };
    static Runtime runtime;
}
inline void close(Handle socket) { closesocket(socket); }
inline int error() { return WSAGetLastError(); }
inline bool interrupted(int error) { return error == WSAEINTR; }
inline bool wouldBlock(int error) { return error == WSAEWOULDBLOCK; }
inline int selectCount(Handle) { return 0; }
#else
using Handle = int;
using Length = socklen_t;
constexpr Handle invalid = -1;
inline void initialize() {}
inline void close(Handle socket) { ::close(socket); }
inline int error() { return errno; }
inline bool interrupted(int error) { return error == EINTR; }
inline bool wouldBlock(int error) { return error == EWOULDBLOCK || error == EAGAIN; }
inline int selectCount(Handle socket) { return socket + 1; }
#endif
inline std::string errorMessage()
{
    return std::system_category().message(error());
}
}}} // namespace moonray::stats::socket_platform
