// SPDX-License-Identifier: Apache-2.0

#pragma once

#include <cstdint>
#include <functional>
#include <string>

namespace moonray {
namespace pbr {

inline std::uint32_t lightSamplingHash(const std::string& name)
{
#ifdef _WIN32
    // std::hash<string> differs between MSVC and libstdc++. Light hashes seed
    // the integrator, so using MSVC's hash changes every lighting sample.
    // Match the existing x86-64 Linux sequence: little-endian MurmurHash64A
    // with libstdc++'s seed, then retain the low 32 bits used by Light::mHash.
    // MurmurHash64A is Austin Appleby's public-domain algorithm:
    // https://github.com/aappleby/smhasher/blob/master/src/MurmurHash2.cpp
    constexpr std::uint64_t multiplier = 0xc6a4a7935bd1e995ULL;
    std::uint64_t hash = 0xc70f6907ULL ^ (std::uint64_t(name.size()) * multiplier);
    std::size_t offset = 0;
    while (name.size() - offset >= 8) {
        std::uint64_t word = 0;
        for (unsigned int byte = 0; byte < 8; ++byte) {
            word |= std::uint64_t(static_cast<unsigned char>(name[offset + byte])) << (8 * byte);
        }
        word *= multiplier;
        word ^= word >> 47;
        word *= multiplier;
        hash ^= word;
        hash *= multiplier;
        offset += 8;
    }
    if (offset != name.size()) {
        std::uint64_t tail = 0;
        for (unsigned int byte = 0; offset + byte < name.size(); ++byte) {
            tail |= std::uint64_t(static_cast<unsigned char>(name[offset + byte])) << (8 * byte);
        }
        hash ^= tail;
        hash *= multiplier;
    }
    hash ^= hash >> 47;
    hash *= multiplier;
    hash ^= hash >> 47;
    return static_cast<std::uint32_t>(hash);
#else
    // Preserve the existing reference sequences on other platforms.
    return static_cast<std::uint32_t>(std::hash<std::string>{}(name));
#endif
}

} // namespace pbr
} // namespace moonray
