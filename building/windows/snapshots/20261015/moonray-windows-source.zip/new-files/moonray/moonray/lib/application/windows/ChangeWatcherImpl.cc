// SPDX-License-Identifier: Apache-2.0
#include "../ChangeWatcher.h"

#include <windows.h>
#include <array>
#include <chrono>
#include <filesystem>
#include <memory>
#include <system_error>
#include <thread>

namespace moonray {
namespace {

void throwLastError(const char* operation)
{
    throw std::system_error(GetLastError(), std::system_category(), operation);
}

class ChangeWatcherWindows : public ChangeWatcher
{
    struct Directory {
        HANDLE handle = INVALID_HANDLE_VALUE;
        OVERLAPPED operation{};
        std::array<DWORD, 8192> buffer{}; // DWORD-aligned, below the network-share 64 KiB limit.
        std::vector<std::pair<std::wstring, std::string>> files;

        ~Directory()
        {
            if (handle != INVALID_HANDLE_VALUE) {
                CancelIoEx(handle, &operation);
                DWORD transferred;
                GetOverlappedResult(handle, &operation, &transferred, TRUE);
                CloseHandle(handle);
            }
            if (operation.hEvent) CloseHandle(operation.hEvent);
        }

        void arm()
        {
            ResetEvent(operation.hEvent);
            if (!ReadDirectoryChangesW(handle, buffer.data(), static_cast<DWORD>(sizeof(buffer)), FALSE,
                    FILE_NOTIFY_CHANGE_FILE_NAME | FILE_NOTIFY_CHANGE_LAST_WRITE | FILE_NOTIFY_CHANGE_SIZE,
                    nullptr, &operation, nullptr)) {
                throwLastError("ReadDirectoryChangesW");
            }
        }
    };

public:
    void watchFile(const std::string& filePath) override
    {
        const auto path = std::filesystem::absolute(std::filesystem::u8path(filePath)).lexically_normal();
        auto& directory = mDirectories[path.parent_path()];
        if (!directory) {
            auto opened = std::make_unique<Directory>();
            opened->operation.hEvent = CreateEventW(nullptr, TRUE, FALSE, nullptr);
            if (!opened->operation.hEvent) throwLastError("CreateEventW");
            opened->handle = CreateFileW(path.parent_path().c_str(), FILE_LIST_DIRECTORY,
                FILE_SHARE_READ | FILE_SHARE_WRITE | FILE_SHARE_DELETE, nullptr, OPEN_EXISTING,
                FILE_FLAG_BACKUP_SEMANTICS | FILE_FLAG_OVERLAPPED, nullptr);
            if (opened->handle == INVALID_HANDLE_VALUE) throwLastError("watchFile");
            opened->arm();
            directory = std::move(opened);
        }
        directory->files.emplace_back(path.filename().wstring(), filePath);
    }

    bool hasChanged(std::set<std::string>* changedFiles = nullptr) override
    {
        bool changed = false;
        for (auto& entry : mDirectories) {
            if (!entry.second) continue; // A previous watchFile call may have failed.
            auto& directory = *entry.second;
            if (WaitForSingleObject(directory.operation.hEvent, 0) != WAIT_OBJECT_0) continue;
            DWORD bytes = 0;
            if (!GetOverlappedResult(directory.handle, &directory.operation, &bytes, FALSE)) {
                throwLastError("file change notification");
            }
            auto mark = [&](const std::string& file) {
                changed = true;
                if (changedFiles) changedFiles->insert(file);
            };
            if (!bytes) {
                // Overflow loses individual names: conservatively invalidate all watched files.
                for (const auto& file : directory.files) mark(file.second);
            } else {
                const auto* notification = reinterpret_cast<const FILE_NOTIFY_INFORMATION*>(directory.buffer.data());
                for (;;) {
                    for (const auto& file : directory.files) {
                        if (CompareStringOrdinal(notification->FileName, notification->FileNameLength / sizeof(wchar_t),
                                file.first.c_str(), static_cast<int>(file.first.size()), TRUE) == CSTR_EQUAL) {
                            mark(file.second);
                        }
                    }
                    if (!notification->NextEntryOffset) break;
                    notification = reinterpret_cast<const FILE_NOTIFY_INFORMATION*>(
                        reinterpret_cast<const char*>(notification) + notification->NextEntryOffset);
                }
            }
            directory.arm();
        }
        return changed;
    }

    void waitForChange() override
    {
        // No handle-count limit: callers can watch more than MAXIMUM_WAIT_OBJECTS directories.
        while (!hasChanged()) std::this_thread::sleep_for(std::chrono::milliseconds(100));
    }

private:
    std::map<std::filesystem::path, std::unique_ptr<Directory>> mDirectories;
};
} // namespace

ChangeWatcher* ChangeWatcher::CreateChangeWatcher()
{
    return new ChangeWatcherWindows();
}
} // namespace moonray
