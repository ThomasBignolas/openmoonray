// SPDX-License-Identifier: Apache-2.0
#pragma once
#include "Export.h"

// Shared by the driver and PBR kernels. Keep cancellation in their common
// runtime so that PBR does not depend on its caller's DLL.
extern "C" MOONRAY_MCRT_COMMON_API bool isRenderCanceled();

namespace moonray { namespace mcrt_common {
MOONRAY_MCRT_COMMON_API void setRenderCanceled(bool canceled);
}}
