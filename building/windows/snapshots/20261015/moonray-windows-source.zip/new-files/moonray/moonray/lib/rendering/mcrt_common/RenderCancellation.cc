// SPDX-License-Identifier: Apache-2.0
#include "RenderCancellation.h"
#include <atomic>

namespace {
// Isolate the frequently read flag from unrelated mutable data.
alignas(64) std::atomic_bool canceled{false};
}

extern "C" bool isRenderCanceled()
{
    return canceled.load(std::memory_order_relaxed);
}

void moonray::mcrt_common::setRenderCanceled(bool value)
{
    canceled.store(value, std::memory_order_relaxed);
}
