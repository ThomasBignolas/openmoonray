// SPDX-License-Identifier: Apache-2.0
#include <moonray/rendering/pbr/sampler/PixelScramble.h>

// ISPC 1.21 cannot mark external data as dllimport. Its test objects are linked
// into this executable, so give them local pointers to the renderer's sampling
// tables. The renderer DLL has its own pointers for its ISPC objects.
extern "C" {
    const std::uint32_t* kISPC8Permutations = moonray::pbr::PixelScramble::getPermutationsPointer();
    const std::uint32_t* kISPCFactorials = moonray::pbr::PixelScramble::sFactorials;
    const std::uint32_t* kISPCFactorialRoundDownPow2 = moonray::pbr::PixelScramble::sFactorialsRoundDownPow2;
    const std::uint32_t* kISPCStrides = moonray::pbr::PixelScramble::sStrides;
}
