// SPDX-License-Identifier: Apache-2.0
#pragma once

#include <windows.h>
#include <io.h>
#include <fcntl.h>
#include <algorithm>
#include <array>
#include <cstdint>
#include <filesystem>
#include <string>
#include <system_error>

namespace moonray { namespace rndr { namespace checkpoint_file {

inline int openTemporary(const std::string& filename, bool create = false)
{
    const DWORD access = GENERIC_READ | DELETE | (create ? GENERIC_WRITE : 0);
    HANDLE handle = CreateFileW(std::filesystem::u8path(filename).c_str(), access,
        FILE_SHARE_READ | FILE_SHARE_WRITE | FILE_SHARE_DELETE, nullptr,
        create ? CREATE_ALWAYS : OPEN_EXISTING, FILE_FLAG_DELETE_ON_CLOSE, nullptr);
    if (handle == INVALID_HANDLE_VALUE) return -1;
    const int fd = _open_osfhandle(reinterpret_cast<intptr_t>(handle),
        (create ? _O_RDWR : _O_RDONLY) | _O_BINARY | _O_NOINHERIT);
    if (fd == -1) CloseHandle(handle);
    return fd;
}

inline bool copyTemporary(int fd, const std::string& destination, std::string& error)
{
    const HANDLE source = reinterpret_cast<HANDLE>(_get_osfhandle(fd));
    LARGE_INTEGER size;
    if (!GetFileSizeEx(source, &size)) {
        error = std::system_category().message(GetLastError());
        return false;
    }
    const HANDLE target = CreateFileW(std::filesystem::u8path(destination).c_str(), GENERIC_WRITE,
        FILE_SHARE_READ, nullptr, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, nullptr);
    if (target == INVALID_HANDLE_VALUE) {
        error = std::system_category().message(GetLastError());
        return false;
    }
    auto fail = [&](DWORD code) {
        error = "Checkpoint copy to '" + destination + "': " + std::system_category().message(code);
        CloseHandle(target);
        return false;
    };
    std::array<char, 65536> buffer;
    for (uint64_t position = 0; position < static_cast<uint64_t>(size.QuadPart);) {
        OVERLAPPED offset{};
        offset.Offset = static_cast<DWORD>(position);
        offset.OffsetHigh = static_cast<DWORD>(position >> 32);
        DWORD read = 0;
        const DWORD amount = static_cast<DWORD>(std::min<uint64_t>(buffer.size(), size.QuadPart - position));
        // A synchronous handle with an explicit offset supports repeat/concurrent copies
        // without relying on a shared file pointer.
        if (!ReadFile(source, buffer.data(), amount, &read, &offset)) return fail(GetLastError());
        if (!read) return fail(ERROR_HANDLE_EOF);
        for (DWORD written = 0; written < read;) {
            DWORD count = 0;
            if (!WriteFile(target, buffer.data() + written, read - written, &count, nullptr)) return fail(GetLastError());
            if (!count) return fail(ERROR_WRITE_FAULT);
            written += count;
        }
        position += read;
    }
    if (!FlushFileBuffers(target)) return fail(GetLastError());
    if (!CloseHandle(target)) {
        error = std::system_category().message(GetLastError());
        return false;
    }
    return true;
}

inline bool replace(const std::string& source, const std::string& destination, std::string& error)
{
    if (MoveFileExW(std::filesystem::u8path(source).c_str(), std::filesystem::u8path(destination).c_str(),
                    MOVEFILE_REPLACE_EXISTING | MOVEFILE_WRITE_THROUGH)) return true;
    error = std::system_category().message(GetLastError());
    return false;
}
}}} // namespace moonray::rndr::checkpoint_file
