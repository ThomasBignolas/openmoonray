# Copyright 2026 DreamWorks Animation LLC
# SPDX-License-Identifier: Apache-2.0
"""Embed unchanged sampling bytes in an aligned x64 COFF object for MSVC.

Format: https://learn.microsoft.com/en-us/windows/win32/debug/pe-format
The start/end symbols have the same address semantics as GNU objcopy's symbols.
"""
import argparse
from pathlib import Path
import re
import shutil
import struct

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("input", type=Path)
parser.add_argument("output", type=Path)
parser.add_argument("start")
parser.add_argument("end")
args = parser.parse_args()
for symbol in (args.start, args.end):
    if not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", symbol):
        parser.error(f"Invalid C symbol: {symbol}")
size = args.input.stat().st_size
if size > 0x7fffffff - 60:
    parser.error("Sampling data exceeds the supported COFF object size")

strings = bytearray(b"\0\0\0\0")
symbols = bytearray()
for name, offset in ((args.start, 0), (args.end, size)):
    symbols += struct.pack("<IIIhHBB", 0, len(strings), offset, 1, 0, 2, 0)
    strings += name.encode("ascii") + b"\0"
struct.pack_into("<I", strings, 0, len(strings))

args.output.parent.mkdir(parents=True, exist_ok=True)
with args.output.open("wb") as output, args.input.open("rb") as source:
    # AMD64, one section, deterministic timestamp, two external data symbols.
    output.write(struct.pack("<HHIIIHH", 0x8664, 1, 0, 60 + size, 2, 0, 0))
    # Read-only initialized data, 64-byte aligned; no relocations or line records.
    output.write(struct.pack("<8sIIIIIIHHI", b".rdata\0\0", 0, 0, size, 60, 0, 0, 0, 0, 0x40700040))
    shutil.copyfileobj(source, output)
    output.write(symbols)
    output.write(strings)
