# SPDX-License-Identifier: Apache-2.0
include_guard(GLOBAL)

# Directory junctions do not require Windows Developer Mode or elevation.
# Keep these links in the build tree: Git may check out source symlinks as text.
function(omr_link_directory source destination)
    if(IS_DIRECTORY "${destination}")
        return()
    endif()
    get_filename_component(parent "${destination}" DIRECTORY)
    file(MAKE_DIRECTORY "${parent}")
    if(WIN32)
        file(TO_NATIVE_PATH "${source}" native_source)
        file(TO_NATIVE_PATH "${destination}" native_destination)
        execute_process(COMMAND cmd /c mklink /J "${native_destination}" "${native_source}"
            RESULT_VARIABLE result OUTPUT_QUIET ERROR_VARIABLE error)
        if(NOT result EQUAL 0)
            message(FATAL_ERROR "Cannot create header junction ${destination}: ${error}")
        endif()
    else()
        file(CREATE_LINK "${source}" "${destination}" SYMBOLIC RESULT result)
        if(NOT result STREQUAL "0")
            message(FATAL_ERROR "Cannot create header link ${destination}: ${result}")
        endif()
    endif()
endfunction()

macro(omr_setup_headers)
    set(PROJECT_SOURCE_INCLUDE_DIR "${PROJECT_SOURCE_DIR}/include")
    if(WIN32)
        set(PROJECT_SOURCE_INCLUDE_DIR "${PROJECT_BINARY_DIR}/source_include")
        omr_link_directory("${PROJECT_SOURCE_DIR}/lib"
            "${PROJECT_SOURCE_INCLUDE_DIR}/${PACKAGE_NAME}")
    endif()
    file(MAKE_DIRECTORY "${PROJECT_BINARY_DIR}/lib")
    omr_link_directory("${PROJECT_BINARY_DIR}/lib"
        "${PROJECT_BINARY_DIR}/include/${PACKAGE_NAME}")
endmacro()

# MSVC does not reliably identify pragma-once headers reached both through a
# junction and their physical path. Compile library sources through the same
# junction used by their qualified includes, so local includes agree as well.
function(omr_use_header_source_paths target)
    if(NOT MSVC)
        return()
    endif()
    get_target_property(sources ${target} SOURCES)
    get_target_property(sourceDir ${target} SOURCE_DIR)
    set(remappedSources)
    foreach(source IN LISTS sources)
        if(NOT source MATCHES "\\$<" AND source MATCHES "\\.(cc|cpp|cxx|c)$")
            get_filename_component(fullSource "${source}" ABSOLUTE BASE_DIR "${sourceDir}")
            file(RELATIVE_PATH relativeSource "${PROJECT_SOURCE_DIR}/lib" "${fullSource}")
            if(EXISTS "${fullSource}" AND NOT relativeSource MATCHES "^\\.\\./"
                    AND NOT IS_ABSOLUTE "${relativeSource}")
                set(source "${PROJECT_SOURCE_INCLUDE_DIR}/${PACKAGE_NAME}/${relativeSource}")
            endif()
        endif()
        list(APPEND remappedSources "${source}")
    endforeach()
    set_property(TARGET ${target} PROPERTY SOURCES "${remappedSources}")
endfunction()
