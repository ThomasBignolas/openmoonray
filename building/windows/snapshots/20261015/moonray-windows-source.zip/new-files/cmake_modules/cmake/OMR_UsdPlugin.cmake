# SPDX-License-Identifier: Apache-2.0
include_guard(GLOBAL)

# Discover plugins from a build tree without changing installed relative paths.
function(omr_stage_usd_plugin component)
    set(LIBRARY_PATH "$<TARGET_FILE:${component}>")
    configure_file("${CMAKE_CURRENT_SOURCE_DIR}/plugInfo.json.in"
        "${CMAKE_CURRENT_BINARY_DIR}/plugInfo.build.in" @ONLY)
    file(GENERATE OUTPUT "${CMAKE_BINARY_DIR}/usd_plugins/$<CONFIG>/${component}/plugInfo.json"
        INPUT "${CMAKE_CURRENT_BINARY_DIR}/plugInfo.build.in")
endfunction()

file(GENERATE OUTPUT "${CMAKE_BINARY_DIR}/usd_plugins/$<CONFIG>/plugInfo.json"
    CONTENT "{\"Includes\": [\"*/\"]}\n")
