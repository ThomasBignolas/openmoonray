// SPDX-License-Identifier: Apache-2.0
#pragma once

#ifdef _WIN32
#ifdef core_messages_EXPORTS
#define CORE_MESSAGES_EXPORT __declspec(dllexport)
#else
#define CORE_MESSAGES_EXPORT __declspec(dllimport)
#endif
#else
#define CORE_MESSAGES_EXPORT
#endif
