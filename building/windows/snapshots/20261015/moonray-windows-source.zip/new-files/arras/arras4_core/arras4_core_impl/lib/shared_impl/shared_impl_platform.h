// SPDX-License-Identifier: Apache-2.0
#pragma once

#ifdef _WIN32
#ifdef shared_impl_EXPORTS
#define SHARED_IMPL_EXPORT __declspec(dllexport)
#else
#define SHARED_IMPL_EXPORT __declspec(dllimport)
#endif
#else
#define SHARED_IMPL_EXPORT
#endif
