// SPDX-License-Identifier: Apache-2.0
#include "Process.h"
#include "ProcessManager.h"
#include "SpawnArgs.h"
#include "IoCapture.h"
#include "WindowsProcessUtil.h"
#include <arras4_log/LogEventStream.h>

#include <algorithm>
#include <atomic>
#include <csignal>
#include <filesystem>
#include <vector>

namespace arras4 { namespace impl {
using windows::Handle;
using windows::check;

namespace {
constexpr int KILL_SIGNAL = 9;
constexpr auto STOP_WAIT = std::chrono::seconds(5);

Handle inheritedHandle(DWORD standard, DWORD access)
{
    HANDLE duplicate = nullptr;
    HANDLE original = GetStdHandle(standard);
    if (original && original != INVALID_HANDLE_VALUE &&
        DuplicateHandle(GetCurrentProcess(), original, GetCurrentProcess(), &duplicate, 0, TRUE, DUPLICATE_SAME_ACCESS))
        return Handle(duplicate);
    SECURITY_ATTRIBUTES security{sizeof(security), nullptr, TRUE};
    Handle result(CreateFileW(L"NUL", access, FILE_SHARE_READ | FILE_SHARE_WRITE, &security,
                              OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, nullptr));
    check(result.get() != INVALID_HANDLE_VALUE, "open NUL stream");
    return result;
}

void capturePipe(Handle& reader, Handle& writer)
{
    SECURITY_ATTRIBUTES security{sizeof(security), nullptr, TRUE};
    HANDLE read = nullptr, write = nullptr;
    check(CreatePipe(&read, &write, &security, 0) != 0, "create output capture pipe");
    reader.reset(read);
    writer.reset(write);
    check(SetHandleInformation(read, HANDLE_FLAG_INHERIT, 0) != 0, "protect capture reader from inheritance");
}

struct Attributes {
    std::vector<unsigned char> storage;
    LPPROC_THREAD_ATTRIBUTE_LIST list = nullptr;
    explicit Attributes(HANDLE* handles, size_t count) {
        SIZE_T size = 0;
        InitializeProcThreadAttributeList(nullptr, 1, 0, &size);
        storage.resize(size);
        auto ptr = reinterpret_cast<LPPROC_THREAD_ATTRIBUTE_LIST>(storage.data());
        check(InitializeProcThreadAttributeList(ptr, 1, 0, &size) != 0, "initialize process attributes");
        list = ptr;
        if (!UpdateProcThreadAttribute(list, 0, PROC_THREAD_ATTRIBUTE_HANDLE_LIST,
                                       handles, count * sizeof(HANDLE), nullptr, nullptr)) {
            DWORD error = GetLastError();
            DeleteProcThreadAttributeList(list);
            throw std::system_error(error, std::system_category(), "set inherited handles");
        }
    }
    ~Attributes() { if (list) DeleteProcThreadAttributeList(list); }
};
}

struct Process::WindowsProcess {
    Handle process, job;
    std::thread stdoutThread, stderrThread;
    std::atomic<bool> stopCapture{false};
    int forcedSignal = 0;

    void capture(Handle reader, const std::shared_ptr<IoCapture>& target, bool errorStream) {
        try {
            char buffer[16384];
            for (;;) {
                DWORD available = 0;
                if (!PeekNamedPipe(reader.get(), nullptr, 0, nullptr, &available, nullptr)) break;
                if (!available) {
                    if (stopCapture) break;
                    std::this_thread::sleep_for(std::chrono::milliseconds(10));
                    continue;
                }
                DWORD count = 0;
                if (!ReadFile(reader.get(), buffer, std::min<DWORD>(available, sizeof(buffer)), &count, nullptr) || !count) break;
                if (errorStream) target->onStderr(buffer, count);
                else target->onStdout(buffer, count);
            }
        } catch (const std::exception& e) {
            ARRAS_ERROR("Process output capture failed: " << e.what());
        } catch (...) {
            ARRAS_ERROR("Process output capture failed");
        }
    }
    void finishCapture() {
        stopCapture = true;
        if (stdoutThread.joinable()) stdoutThread.join();
        if (stderrThread.joinable()) stderrThread.join();
    }
    ~WindowsProcess() { finishCapture(); }
};

Process::Process(const api::UUID& id, const std::string& name, const api::UUID& sessionId,
                 ProcessManager& manager) :
    mId(id), mName(name), mSessionId(sessionId), mManager(manager),
    mState(ProcessState::NotSpawned), mStatus(ExitType::Internal, ExitStatus::NO_EXIT)
{
    if (id.isNull() || sessionId.isNull() || name.empty())
        throw std::invalid_argument("Process requires an id, session id and name");
}

Process::~Process()
{
    if (mTerminationThread.joinable()) mTerminationThread.join();
    // ProcessManager terminates its children before releasing its references.
    if (mWindows && mWindows->process.get() && WaitForSingleObject(mWindows->process.get(), 0) == WAIT_TIMEOUT) {
        TerminateJobObject(mWindows->job.get(), KILL_SIGNAL);
        WaitForSingleObject(mWindows->process.get(), 5000);
    }
}

ProcessId Process::pid() { std::lock_guard<std::mutex> lock(mStateMutex); return mPid; }
ProcessState Process::state() { std::lock_guard<std::mutex> lock(mStateMutex); return mState; }
ExitStatus Process::status() { std::lock_guard<std::mutex> lock(mStateMutex); return mStatus; }
void Process::state(ProcessState& state, ProcessId& pid, ExitStatus& status) {
    std::lock_guard<std::mutex> lock(mStateMutex);
    state = mState; pid = mPid; status = mStatus;
}

StateChange Process::spawn(const SpawnArgs& args)
{
    std::unique_lock<std::mutex> lock(mStateMutex);
    if (atLeast(ProcessState::Terminating)) return StateChange::Invalid;
    if (mState == ProcessState::Spawned) return StateChange::Achieved;
    mObserver = args.observer;
    mCleanupProcessGroup = args.cleanupProcessGroup;
    try {
        SpawnArgs resolved(args);
        if (!resolved.findProgramInPath(args.program))
            throw std::runtime_error("Executable was not found: " + args.program);
        const auto executable = windows::wide(resolved.program);
        auto command = windows::quote(executable);
        for (const auto& arg : args.args) command += L" " + windows::quote(windows::wide(arg));
        auto cwd = windows::wide(args.workingDirectory);
        std::vector<std::wstring> variables;
        for (const auto& value : args.environment.asVector()) variables.push_back(windows::wide(value));
        std::sort(variables.begin(), variables.end(), [](const auto& a, const auto& b) {
            return CompareStringOrdinal(a.c_str(), -1, b.c_str(), -1, TRUE) == CSTR_LESS_THAN;
        });
        std::vector<wchar_t> environment;
        for (const auto& value : variables) {
            environment.insert(environment.end(), value.begin(), value.end());
            environment.push_back(0);
        }
        environment.push_back(0);
        if (variables.empty()) environment.push_back(0);

        auto state = std::make_unique<WindowsProcess>();
        state->job.reset(CreateJobObjectW(nullptr, nullptr));
        check(state->job.get() != nullptr, "create child process job");
        JOBOBJECT_EXTENDED_LIMIT_INFORMATION limits{};
        if (mCleanupProcessGroup) limits.BasicLimitInformation.LimitFlags = JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE;
        if (args.enforceMemory && mManager.mEnforceMemory) {
            if (!args.assignedMb) throw std::invalid_argument("An enforced memory limit must be positive");
            limits.BasicLimitInformation.LimitFlags |= JOB_OBJECT_LIMIT_JOB_MEMORY;
            limits.JobMemoryLimit = SIZE_T(args.assignedMb) * 1024 * 1024;
        }
        check(SetInformationJobObject(state->job.get(), JobObjectExtendedLimitInformation, &limits, sizeof(limits)) != 0,
              "set child job limits");
        if (args.enforceCores && mManager.mEnforceCpu) {
            if (!args.assignedCores) throw std::invalid_argument("An enforced CPU limit must be positive");
            const DWORD processors = GetActiveProcessorCount(ALL_PROCESSOR_GROUPS);
            check(processors != 0, "get processor count");
            JOBOBJECT_CPU_RATE_CONTROL_INFORMATION cpu{};
            cpu.ControlFlags = JOB_OBJECT_CPU_RATE_CONTROL_ENABLE | JOB_OBJECT_CPU_RATE_CONTROL_HARD_CAP;
            cpu.CpuRate = static_cast<DWORD>(std::min<uint64_t>(10000, uint64_t(args.assignedCores) * 10000 / processors));
            cpu.CpuRate = std::max<DWORD>(1, cpu.CpuRate);
            check(SetInformationJobObject(state->job.get(), JobObjectCpuRateControlInformation, &cpu, sizeof(cpu)) != 0,
                  "set child CPU limit");
        }

        Handle input = inheritedHandle(STD_INPUT_HANDLE, GENERIC_READ);
        Handle output, error, stdoutReader, stderrReader;
        if (args.ioCapture) {
            capturePipe(stdoutReader, output);
            capturePipe(stderrReader, error);
        } else {
            output = inheritedHandle(STD_OUTPUT_HANDLE, GENERIC_WRITE);
            error = inheritedHandle(STD_ERROR_HANDLE, GENERIC_WRITE);
        }
        HANDLE handles[] = {input.get(), output.get(), error.get()};
        Attributes attributes(handles, 3);
        STARTUPINFOEXW startup{};
        startup.StartupInfo.cb = sizeof(startup);
        startup.StartupInfo.dwFlags = STARTF_USESTDHANDLES;
        startup.StartupInfo.hStdInput = input.get();
        startup.StartupInfo.hStdOutput = output.get();
        startup.StartupInfo.hStdError = error.get();
        startup.lpAttributeList = attributes.list;
        PROCESS_INFORMATION info{};
        check(CreateProcessW(executable.c_str(), command.data(), nullptr, nullptr, TRUE,
                             CREATE_SUSPENDED | CREATE_NO_WINDOW | CREATE_UNICODE_ENVIRONMENT | EXTENDED_STARTUPINFO_PRESENT,
                             environment.data(), cwd.empty() ? nullptr : cwd.c_str(), &startup.StartupInfo, &info) != 0,
              "create child process");
        state->process.reset(info.hProcess);
        Handle mainThread(info.hThread);
        try {
            check(AssignProcessToJobObject(state->job.get(), state->process.get()) != 0, "assign child to job");
            if (args.ioCapture) {
                state->stdoutThread = std::thread(&WindowsProcess::capture, state.get(), std::move(stdoutReader), args.ioCapture, false);
                state->stderrThread = std::thread(&WindowsProcess::capture, state.get(), std::move(stderrReader), args.ioCapture, true);
            }
            check(ResumeThread(mainThread.get()) != DWORD(-1), "resume child process");
        } catch (...) {
            TerminateProcess(state->process.get(), KILL_SIGNAL);
            WaitForSingleObject(state->process.get(), 5000);
            throw;
        }
        mWindows = std::move(state);
        mPid = info.dwProcessId;
        mState = ProcessState::Spawned;
        mStatus = ExitStatus(ExitType::Internal, ExitStatus::NO_EXIT);
        mManager.postFork_cb(*this);
        if (mObserver) mObserver->onSpawn(mId, mSessionId, mPid);
        return StateChange::Success;
    } catch (const std::exception& e) {
        ARRAS_ERROR("Failed to spawn " << logname() << ": " << e.what());
        if (mWindows && mWindows->process.get()) TerminateJobObject(mWindows->job.get(), KILL_SIGNAL);
        lock.unlock();
        terminated(ExitStatus(ExitType::Internal, ExitStatus::FORK_FAILED));
        return StateChange::Terminated;
    }
}

void Process::collectExit()
{
    std::unique_lock<std::mutex> lock(mStateMutex);
    if (!mWindows || atLeast(ProcessState::Terminated) ||
        WaitForSingleObject(mWindows->process.get(), 0) != WAIT_OBJECT_0) return;
    DWORD code = 0;
    ExitStatus result(ExitType::Internal, ExitStatus::UNKNOWN);
    if (GetExitCodeProcess(mWindows->process.get(), &code))
        result = mWindows->forcedSignal ? ExitStatus(ExitType::Signal, mWindows->forcedSignal) : ExitStatus(ExitType::Exit, code);
    if (mCleanupProcessGroup) TerminateJobObject(mWindows->job.get(), KILL_SIGNAL);
    lock.unlock();
    mWindows->finishCapture();
    terminated(result);
}

void Process::terminated(const ExitStatus& status)
{
    std::shared_ptr<ProcessObserver> observer;
    {
        std::lock_guard<std::mutex> lock(mStateMutex);
        if (mState == ProcessState::Terminated) return;
        mManager.exit_cb(*this);
        mStatus = status;
        mState = ProcessState::Terminated;
        mPid = 0;
        observer = std::move(mObserver);
    }
    mExitCondition.notify_all();
    if (observer) {
        try { observer->onTerminate(mId, mSessionId, status); }
        catch (const std::exception& e) { ARRAS_ERROR("Process exit observer failed: " << e.what()); }
        catch (...) { ARRAS_ERROR("Process exit observer failed"); }
    }
}

void Process::terminated_internal(int code) { terminated(ExitStatus(ExitType::Internal, code)); }

StateChange Process::terminate(bool fast)
{
    std::unique_lock<std::mutex> lock(mStateMutex);
    if (mState == ProcessState::Terminated) return StateChange::Achieved;
    if (mState == ProcessState::NotSpawned) {
        lock.unlock();
        terminated_internal(ExitStatus::NOT_SPAWNED);
        return StateChange::Success;
    }
    if (mState == ProcessState::Terminating) {
        if (fast) {
            mWindows->forcedSignal = KILL_SIGNAL;
            check(TerminateJobObject(mWindows->job.get(), KILL_SIGNAL) != 0, "terminate child job");
        }
        return StateChange::InProgress;
    }
    mState = ProcessState::Terminating;
    try { mTerminationThread = std::thread(&Process::terminationProc, this, fast); }
    catch (...) { mState = ProcessState::Spawned; throw; }
    return StateChange::InProgress;
}

void Process::terminationProc(bool fast)
{
    try {
        std::unique_lock<std::mutex> lock(mStateMutex);
        if (mState != ProcessState::Terminating) return;
        if (!fast && mManager.controlledStop(*this) && waitForExit_wlock(lock, STOP_WAIT)) return;
        if (mState == ProcessState::Terminated) return;
        mWindows->forcedSignal = fast ? KILL_SIGNAL : SIGTERM;
        check(TerminateJobObject(mWindows->job.get(), mWindows->forcedSignal) != 0, "terminate child job");
    } catch (const std::exception& e) {
        ARRAS_ERROR("Failed to terminate " << logname() << ": " << e.what());
        // Keep tracking the real process; do not report it as exited while it is alive.
    }
}

void Process::signal(int signum, bool sendToGroup)
{
    std::lock_guard<std::mutex> lock(mStateMutex);
    if (!mPid) return;
    if (signum != SIGTERM && signum != KILL_SIGNAL)
        throw std::invalid_argument("Windows supports termination requests, not POSIX process signals");
    mWindows->forcedSignal = signum;
    check((sendToGroup ? TerminateJobObject(mWindows->job.get(), signum) :
           TerminateProcess(mWindows->process.get(), signum)) != 0, "terminate child process");
}

StateChange Process::reset()
{
    { std::lock_guard<std::mutex> lock(mStateMutex); if (mState != ProcessState::Terminated) return StateChange::Invalid; }
    if (mTerminationThread.joinable()) mTerminationThread.join();
    std::lock_guard<std::mutex> lock(mStateMutex);
    mWindows.reset();
    mStatus = ExitStatus(ExitType::Internal, ExitStatus::NO_EXIT);
    mState = ProcessState::NotSpawned;
    return StateChange::Success;
}

void Process::waitForExit(ExitStatus* status) {
    std::unique_lock<std::mutex> lock(mStateMutex);
    waitForExit_wlock(lock);
    if (status) *status = mStatus;
}
bool Process::waitForExit(ExitStatus* status, const std::chrono::milliseconds& timeout) {
    return waitUntilExit(status, std::chrono::steady_clock::now() + timeout);
}
bool Process::waitUntilExit(ExitStatus* status, const std::chrono::steady_clock::time_point& time) {
    std::unique_lock<std::mutex> lock(mStateMutex);
    if (!waitUntilExit_wlock(lock, time)) return false;
    if (status) *status = mStatus;
    return true;
}
void Process::waitForExit_wlock(std::unique_lock<std::mutex>& lock) {
    mExitCondition.wait(lock, [this] { return mState == ProcessState::Terminated; });
}
bool Process::waitForExit_wlock(std::unique_lock<std::mutex>& lock, const std::chrono::milliseconds& timeout) {
    return waitUntilExit_wlock(lock, std::chrono::steady_clock::now() + timeout);
}
bool Process::waitUntilExit_wlock(std::unique_lock<std::mutex>& lock, const std::chrono::steady_clock::time_point& time) {
    return mExitCondition.wait_until(lock, time, [this] { return mState == ProcessState::Terminated; });
}
std::string ExitStatus::internalCodeString(int code) {
    switch (code) {
    case NO_EXIT: return "has not exited";
    case PROCESS_DELETED: return "process object was deleted";
    case FORK_FAILED: return "Windows process creation failed";
    case NOT_SPAWNED: return "did not run";
    case UNINTERRUPTABLE: return "cannot be terminated";
    default: return "execution status is unknown";
    }
}
bool ExitStatus::convertHighExitToSignal() { return false; } // Windows exit codes are not POSIX shell statuses.
}}
