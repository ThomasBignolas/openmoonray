// SPDX-License-Identifier: Apache-2.0
#pragma once
#include <windows.h>
#include <string>
#include <stdexcept>
#include <system_error>
#include <utility>

namespace arras4 { namespace impl { namespace windows {
inline void check(bool success, const char* operation) {
    if (!success) throw std::system_error(GetLastError(), std::system_category(), operation);
}
inline std::wstring wide(const std::string& value) {
    if (value.empty()) return {};
    int size = MultiByteToWideChar(CP_UTF8, MB_ERR_INVALID_CHARS, value.data(), static_cast<int>(value.size()), nullptr, 0);
    check(size > 0, "decode UTF-8");
    std::wstring result(size, L'\0');
    check(MultiByteToWideChar(CP_UTF8, MB_ERR_INVALID_CHARS, value.data(), static_cast<int>(value.size()), result.data(), size) > 0, "decode UTF-8");
    return result;
}
inline std::string utf8(const std::wstring& value) {
    if (value.empty()) return {};
    int size = WideCharToMultiByte(CP_UTF8, WC_ERR_INVALID_CHARS, value.data(), static_cast<int>(value.size()), nullptr, 0, nullptr, nullptr);
    check(size > 0, "encode UTF-8");
    std::string result(size, '\0');
    check(WideCharToMultiByte(CP_UTF8, WC_ERR_INVALID_CHARS, value.data(), static_cast<int>(value.size()), result.data(), size, nullptr, nullptr) > 0, "encode UTF-8");
    return result;
}
// Encode one argv element using the Microsoft C runtime's backslash/quote rules.
inline std::wstring quote(const std::wstring& value) {
    std::wstring result(1, L'"');
    size_t slashes = 0;
    for (wchar_t c : value) {
        if (c == L'\\') { ++slashes; continue; }
        result.append(c == L'"' ? 2 * slashes + 1 : slashes, L'\\');
        result += c;
        slashes = 0;
    }
    result.append(2 * slashes, L'\\');
    return result + L'"';
}
class Handle {
public:
    explicit Handle(HANDLE value = nullptr) : mValue(value) {}
    ~Handle() { reset(); }
    Handle(const Handle&) = delete;
    Handle& operator=(const Handle&) = delete;
    Handle(Handle&& other) noexcept : mValue(other.release()) {}
    Handle& operator=(Handle&& other) noexcept { reset(other.release()); return *this; }
    HANDLE get() const { return mValue; }
    HANDLE release() { return std::exchange(mValue, nullptr); }
    void reset(HANDLE value = nullptr) {
        if (mValue && mValue != INVALID_HANDLE_VALUE) CloseHandle(mValue);
        mValue = value;
    }
private:
    HANDLE mValue;
};
}}}
