// SPDX-License-Identifier: Apache-2.0
#include "ProcessManager.h"
#include "ProcessController.h"
#include <stdexcept>

namespace arras4 { namespace impl {
ProcessManager::ProcessManager(unsigned availableMemoryMb, bool useCgroups, bool enforceMemory,
                               bool enforceCpu, bool loanMemory) :
    mRunThreads(true), mUseControlGroups(false), mEnforceMemory(enforceMemory),
    mLoanMemory(false), mEnforceCpu(enforceCpu)
{
    if (useCgroups || loanMemory) throw std::invalid_argument("Linux cgroups and memory loans are unavailable on Windows");
    mMemory.set(availableMemoryMb);
    mExitMonitorThread = std::thread(&ProcessManager::exitMonitorProc, this);
}
ProcessManager::~ProcessManager()
{
    std::vector<Process::Ptr> processes;
    { std::lock_guard<std::mutex> lock(mProcessesMutex); for (auto& item : mProcesses) processes.push_back(item.second); }
    for (auto& process : processes) process->terminate(true);
    for (auto& process : processes) process->waitForExit(nullptr);
    mRunThreads = false;
    if (mExitMonitorThread.joinable()) mExitMonitorThread.join();
    mProcesses.clear();
}
void ProcessManager::setProcessController(std::shared_ptr<ProcessController> controller)
{
    std::lock_guard<std::mutex> lock(mProcessesMutex);
    mProcessController = std::move(controller);
}
Process::Ptr ProcessManager::addProcess(const api::UUID& id, const std::string& name, const api::UUID& sessionId)
{
    auto process = std::make_shared<Process>(id, name.empty() ? "Process_" + id.toString() : name,
                                            sessionId.isNull() ? id : sessionId, *this);
    std::lock_guard<std::mutex> lock(mProcessesMutex);
    if (!mProcesses.emplace(id, process).second) throw std::invalid_argument("Duplicate process id");
    return process;
}
Process::Ptr ProcessManager::getProcess_wlock(const api::UUID& id)
{
    auto it = mProcesses.find(id);
    return it == mProcesses.end() ? Process::Ptr() : it->second;
}
Process::Ptr ProcessManager::getProcess(const api::UUID& id)
{
    std::lock_guard<std::mutex> lock(mProcessesMutex);
    return getProcess_wlock(id);
}
bool ProcessManager::removeProcess(const api::UUID& id)
{
    auto process = getProcess(id);
    if (!process) return false;
    process->terminate(true);
    process->waitForExit(nullptr);
    std::lock_guard<std::mutex> lock(mProcessesMutex);
    mProcesses.erase(id);
    return true;
}
void ProcessManager::postFork_cb(Process& process)
{
    std::lock_guard<std::mutex> lock(mProcessesMutex);
    auto found = getProcess_wlock(process.id());
    if (found) mPidToProcess[process.mPid] = found;
}
void ProcessManager::exit_cb(Process& process)
{
    std::lock_guard<std::mutex> lock(mProcessesMutex);
    mPidToProcess.erase(process.mPid);
}
bool ProcessManager::controlledStop(Process& process)
{
    std::shared_ptr<ProcessController> controller;
    { std::lock_guard<std::mutex> lock(mProcessesMutex); controller = mProcessController; }
    return controller && controller->sendStop(process.id(), process.sessionId());
}
void ProcessManager::exitMonitorProc()
{
    while (mRunThreads) {
        std::vector<Process::Ptr> processes;
        { std::lock_guard<std::mutex> lock(mProcessesMutex); for (auto& item : mPidToProcess) processes.push_back(item.second); }
        for (auto& process : processes) process->collectExit();
        std::this_thread::sleep_for(std::chrono::milliseconds(10));
    }
}
}}
