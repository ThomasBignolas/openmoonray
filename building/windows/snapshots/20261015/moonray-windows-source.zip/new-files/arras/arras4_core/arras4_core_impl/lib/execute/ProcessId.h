// SPDX-License-Identifier: Apache-2.0
#pragma once
#ifndef _WIN32
#include <sys/types.h>
#endif
namespace arras4 { namespace impl {
#ifdef _WIN32
using ProcessId = unsigned long; // Windows DWORD process identifier.
#else
using ProcessId = pid_t;
#endif
}}
