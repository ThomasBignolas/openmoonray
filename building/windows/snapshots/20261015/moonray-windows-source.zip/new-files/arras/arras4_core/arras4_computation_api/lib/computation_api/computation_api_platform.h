// SPDX-License-Identifier: Apache-2.0
#pragma once

#ifdef _WIN32
#ifdef computation_api_EXPORTS
#define COMPUTATION_API_EXPORT __declspec(dllexport)
#else
#define COMPUTATION_API_EXPORT __declspec(dllimport)
#endif
#define COMPUTATION_DSO_EXPORT __declspec(dllexport)
#else
#define COMPUTATION_API_EXPORT
#define COMPUTATION_DSO_EXPORT
#endif
