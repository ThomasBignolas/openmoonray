// SPDX-License-Identifier: Apache-2.0
#pragma once
#ifdef _WIN32
#ifdef node_messages_EXPORTS
#define NODE_MESSAGES_EXPORT __declspec(dllexport)
#else
#define NODE_MESSAGES_EXPORT __declspec(dllimport)
#endif
#else
#define NODE_MESSAGES_EXPORT
#endif
