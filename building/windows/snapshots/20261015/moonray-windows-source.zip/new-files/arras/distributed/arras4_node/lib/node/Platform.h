// SPDX-License-Identifier: Apache-2.0
#pragma once
#ifdef _WIN32
#include <network/network_platform.h>
#include <network/windows_utils.h>
#include <stdexcept>
namespace arras4 { namespace node {
class WindowsSockets {
public:
    WindowsSockets() {
        WSADATA data{};
        if (WSAStartup(MAKEWORD(2, 2), &data)) throw std::runtime_error("WSAStartup failed");
    }
    ~WindowsSockets() { WSACleanup(); }
    WindowsSockets(const WindowsSockets&) = delete;
    WindowsSockets& operator=(const WindowsSockets&) = delete;
};
}}
inline tm* localtime_r(const time_t* value, tm* result)
{
    return localtime_s(result, value) == 0 ? result : nullptr;
}
#else
#include <unistd.h>
#include <sys/time.h>
#endif
