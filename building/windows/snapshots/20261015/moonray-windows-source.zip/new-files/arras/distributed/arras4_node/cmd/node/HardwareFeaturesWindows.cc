// SPDX-License-Identifier: Apache-2.0
#include "HardwareFeatures.h"
#include <Windows.h>
#include <intrin.h>
#include <setupapi.h>
#include <algorithm>
#include <cstring>
#include <cwctype>
#include <stdexcept>

unsigned HardwareFeatures::getCoreCount()
{
    return GetActiveProcessorCount(ALL_PROCESSOR_GROUPS);
}

unsigned HardwareFeatures::getProcessorInfo(std::vector<ProcessorInfo>& info, const std::string&)
{
    int registers[4]{};
    __cpuid(registers, 0x80000000);
    char brand[49]{};
    if (static_cast<unsigned>(registers[0]) >= 0x80000004u) {
        for (unsigned i = 0; i != 3; ++i) {
            __cpuid(registers, 0x80000002u + i);
            std::memcpy(brand + 16 * i, registers, 16);
        }
    }
    __cpuid(registers, 1);
    unsigned model = ((registers[0] >> 4) & 15) | ((registers[0] >> 12) & 240);
    std::vector<std::string> flags;
    bool avxState = (registers[2] & (1 << 27)) && ((_xgetbv(0) & 6) == 6);
    if (avxState && (registers[2] & (1 << 28))) flags.push_back("avx");
    __cpuidex(registers, 7, 0);
    if (avxState && (registers[1] & (1 << 5))) flags.push_back("avx2");
    auto topology = [](LOGICAL_PROCESSOR_RELATIONSHIP relationship) {
        DWORD size = 0;
        GetLogicalProcessorInformationEx(relationship, nullptr, &size);
        std::vector<unsigned char> data(size);
        if (!size || !GetLogicalProcessorInformationEx(relationship,
            reinterpret_cast<PSYSTEM_LOGICAL_PROCESSOR_INFORMATION_EX>(data.data()), &size))
            throw std::runtime_error("Cannot query Windows processor topology");
        return data;
    };
    std::map<std::pair<WORD, unsigned>, unsigned short> packages;
    auto data = topology(RelationProcessorPackage);
    unsigned short chip = 0;
    for (size_t offset = 0; offset < data.size(); ++chip) {
        auto* item = reinterpret_cast<PSYSTEM_LOGICAL_PROCESSOR_INFORMATION_EX>(data.data() + offset);
        for (WORD group = 0; group < item->Processor.GroupCount; ++group) {
            const auto& mask = item->Processor.GroupMask[group];
            for (unsigned bit = 0; bit < sizeof(KAFFINITY) * 8; ++bit)
                if (mask.Mask & (KAFFINITY(1) << bit)) packages[{mask.Group, bit}] = chip;
        }
        offset += item->Size;
    }
    data = topology(RelationProcessorCore);
    unsigned short core = 0;
    info.clear();
    for (size_t offset = 0; offset < data.size(); ++core) {
        auto* item = reinterpret_cast<PSYSTEM_LOGICAL_PROCESSOR_INFORMATION_EX>(data.data() + offset);
        for (WORD group = 0; group < item->Processor.GroupCount; ++group) {
            const auto& mask = item->Processor.GroupMask[group];
            for (unsigned bit = 0; bit < sizeof(KAFFINITY) * 8; ++bit) {
                if (!(mask.Mask & (KAFFINITY(1) << bit))) continue;
                ProcessorInfo value{};
                value.mId = static_cast<unsigned short>(info.size());
                value.mCore = core;
                value.mChip = packages.at({mask.Group, bit});
                value.mModel = static_cast<unsigned short>(model);
                value.mModelName = brand;
                value.mFlags = flags;
                info.push_back(std::move(value));
            }
        }
        offset += item->Size;
    }
    return static_cast<unsigned>(info.size());
}

unsigned long long HardwareFeatures::getMemoryInBytes()
{
    MEMORYSTATUSEX memory{sizeof(memory)};
    if (!GlobalMemoryStatusEx(&memory)) throw std::runtime_error("Cannot query Windows physical memory");
    return memory.ullTotalPhys;
}

unsigned HardwareFeatures::getDeviceCount(const std::string& deviceID)
{
    if (deviceID.size() != 4 || deviceID.find_first_not_of("0123456789abcdefABCDEF") != std::string::npos)
        throw std::invalid_argument("PCI device ID must have four hexadecimal digits");
    std::wstring match = L"DEV_" + std::wstring(deviceID.begin(), deviceID.end());
    std::transform(match.begin(), match.end(), match.begin(), towupper);
    HDEVINFO devices = SetupDiGetClassDevsW(nullptr, L"PCI", nullptr, DIGCF_PRESENT | DIGCF_ALLCLASSES);
    if (devices == INVALID_HANDLE_VALUE) throw std::runtime_error("Cannot enumerate PCI devices");
    unsigned count = 0;
    SP_DEVINFO_DATA item{sizeof(item)};
    for (DWORD i = 0; SetupDiEnumDeviceInfo(devices, i, &item); ++i) {
        WCHAR ids[4096]{};
        if (SetupDiGetDeviceRegistryPropertyW(devices, &item, SPDRP_HARDWAREID, nullptr,
                                              reinterpret_cast<PBYTE>(ids), sizeof(ids), nullptr)) {
            std::wstring id(ids);
            std::transform(id.begin(), id.end(), id.begin(), towupper);
            if (id.find(match) != std::wstring::npos) ++count;
        }
    }
    SetupDiDestroyDeviceInfoList(devices);
    return count;
}

unsigned HardwareFeatures::getMICCount() { return getDeviceCount("225c"); }
HardwareFeatures::ProcessorList HardwareFeatures::parseProcInfo(const std::string&)
{
    throw std::logic_error("Use the native Windows processor topology query, not /proc/cpuinfo");
}
